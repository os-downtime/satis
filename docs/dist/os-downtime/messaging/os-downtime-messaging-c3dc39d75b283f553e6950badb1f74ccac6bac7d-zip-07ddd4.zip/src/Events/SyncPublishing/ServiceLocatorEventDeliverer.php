<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\SyncPublishing;

use OsDownTime\Common\Domain\Event;
use Psr\Container\ContainerInterface;

final readonly class ServiceLocatorEventDeliverer implements EventDeliverer
{
    public function __construct(private ContainerInterface $locator, private array $handlersPerEvent = [])
    {
    }

    public function deliver(?string $onlyToEventHandlerWithId, Event ...$events): void
    {
        foreach ($events as $event) {
            $this->doDeliver($onlyToEventHandlerWithId, $event);
        }
    }

    private function doDeliver(?string $eventHandlerId, Event $event): void
    {
        $handlers = $this->handlersPerEvent[$event::class] ?? [];

        if (0 === count($handlers)) {
            throw new \RuntimeException(sprintf("No handler found for event '%s'", $event::class));
        }

        foreach ($handlers as $handler) {
            if (null !== $eventHandlerId && $eventHandlerId !== $handler) {
                continue;
            }

            if (!$this->locator->has($handler)) {
                throw new \RuntimeException(sprintf("Handler %s for event '%s' can not be located", $handler, $event::class));
            }

            $this->locator->get($handler)->reactTo($event);
        }
    }

    public function eventTypesHandledBy(string $eventHandlerWithId): array
    {
        $eventTypes = [];

        foreach ($this->handlersPerEvent as $eventType => $handlers) {
            if (in_array($eventHandlerWithId, $handlers, true)) {
                $eventTypes[] = $eventType;
            }
        }

        return $eventTypes;
    }
}
