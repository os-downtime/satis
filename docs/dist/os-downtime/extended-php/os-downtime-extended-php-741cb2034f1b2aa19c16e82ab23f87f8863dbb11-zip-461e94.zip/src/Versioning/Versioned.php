<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Versioning;

/**
 *  TODO: take advantage of new PHP 8.4 interface features.
 */
interface Versioned
{
    public function version(): int;

    public function withVersion(int $version): void;
}
