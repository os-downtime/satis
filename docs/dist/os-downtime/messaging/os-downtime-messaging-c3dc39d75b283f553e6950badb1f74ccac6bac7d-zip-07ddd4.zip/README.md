# Messaging for applications based on the "Common" package

## Install instructions
- Install the package
- Ensure your command and event handlers are tagged. This can be done with:
```php
    $services
        ->instanceof(CommandHandler::class)
        ->tag(LocateCommandHandlerCompilerPass::COMMAND_HANDLER_TAG)
    ;
    $services
        ->instanceof(EventHandler::class)
        ->tag(LocateEventHandlersCompilerPass::EVENT_HANDLER_TAG)
    ;
```
```yaml
    _instanceof:
        OsDownTime\Messaging\Commands\CommandHandler:
            tags: [ !php/const OsDownTime\Messaging\DependencyInjection\LocateCommandHandlerCompilerPass::COMMAND_HANDLER_TAG ]
        OsDownTime\Messaging\Events\EventHandler:
            tags: [ !php/const OsDownTime\Messaging\DependencyInjection\LocateEventHandlersCompilerPass::EVENT_HANDLER_TAG ]
```
- Register the Symfony bundle
```php
    OsDownTime\Messaging\OsDownTimeMessagingBundle::class => ['all' => true],
```
- or manually register the extension and compiler passes
- Your can now inject `OsDownTime\Common\Application\CommandBus` as alias of `OsDownTime\Messaging\Commands\ServiceLocatorCommandBus`.
- And `OsDownTime\Common\Domain\EventBus` as alias of `OsDownTime\Messaging\Events\SyncPublishing\ServiceLocatorEventBus`. 
