<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Retrieving\EventRetriever;

final readonly class PointerBasedRelay implements Relay
{
    public function __construct(private PointerStore $pointerStore, private EventRetriever $eventDeliverer)
    {
    }

    public function batcherFor(string $workerId, string $eventHandlerId, \Closure $batcherHandler): void
    {
        $this->pointerStore->usingContextFor($workerId, $eventHandlerId, function (PointerContext $context) use ($batcherHandler) {
            $batcherHandler(new PointerBasedBatcher($context, $this->eventDeliverer));
        });
    }
}
