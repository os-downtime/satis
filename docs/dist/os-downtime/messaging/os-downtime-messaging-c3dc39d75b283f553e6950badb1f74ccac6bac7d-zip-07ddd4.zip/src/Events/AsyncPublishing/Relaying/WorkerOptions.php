<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

final readonly class WorkerOptions
{
    public function __construct(
        public int $batchSize,
        public string $eventHandlerId,
        public int $maxEventsToRelay,
        public int $secondsToSleepOnEmptyQueue,
        public string $workerId,
    ) {
    }
}
