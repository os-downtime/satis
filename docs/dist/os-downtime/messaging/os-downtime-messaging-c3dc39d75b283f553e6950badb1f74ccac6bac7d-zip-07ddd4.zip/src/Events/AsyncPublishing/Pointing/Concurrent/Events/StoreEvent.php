<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

interface StoreEvent
{
    public static function eventName(): EventName;
}
