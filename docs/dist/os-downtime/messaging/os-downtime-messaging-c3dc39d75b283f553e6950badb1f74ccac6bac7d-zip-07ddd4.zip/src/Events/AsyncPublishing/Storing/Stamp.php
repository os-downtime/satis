<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Storing;

final readonly class Stamp
{
    public const string UNIQUE_EVENT_ID = 'unique_event_id';

    public function __construct(public string $name, public string $value)
    {
    }
}
