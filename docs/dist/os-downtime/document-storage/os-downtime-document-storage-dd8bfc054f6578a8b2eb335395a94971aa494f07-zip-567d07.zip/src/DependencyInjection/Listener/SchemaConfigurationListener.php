<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\DependencyInjection\Listener;

use Doctrine\ORM\Tools\Event\GenerateSchemaEventArgs;
use OsDownTime\DocumentStorage\Stores\Dbal\AbleToConfigureSchema;
use Symfony\Bridge\Doctrine\SchemaListener\AbstractSchemaListener;

final class SchemaConfigurationListener extends AbstractSchemaListener
{
    /**
     * @param AbleToConfigureSchema[] $allAbleToConfigure
     */
    public function __construct(private array $allAbleToConfigure)
    {
    }

    public function postGenerateSchema(GenerateSchemaEventArgs $event): void
    {
        $connection = $event->getEntityManager()->getConnection();

        foreach ($this->allAbleToConfigure as $ableToConfigure) {
            $configurator = $ableToConfigure->configurator();
            $configurator->configureSchema($event->getSchema(), $this->getIsSameDatabaseChecker($connection));
        }
    }
}
