<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils\PartitionableCollection;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;

final class PartitionableCollection
{
    private int $globalAddOrder;
    private int $globalHandleOrder;
    private int $handledPointersCount;
    /**
     * @var PartitionableItem[]
     */
    private array $items;

    public function __construct()
    {
        $this->globalAddOrder = 1;
        $this->globalHandleOrder = 1;
        $this->handledPointersCount = 0;
        $this->items = [];
    }

    public function add(PartitionableItem $item): void
    {
        $item->globalOrder = $this->globalAddOrder;
        $this->items[$this->globalAddOrder] = $item;
        ++$this->globalAddOrder;
    }

    public function handle(Pointer $pointer): Pointer
    {
        ++$this->handledPointersCount;

        /** @var PartitionableItem[] $inRange */
        $inRange = array_filter($this->items, fn (PartitionableItem $item) => $item->hash >= $pointer->minHash() && $item->hash <= $pointer->maxHash());

        usort($inRange, fn (PartitionableItem $a, PartitionableItem $b) => $a->globalOrder <=> $b->globalOrder);

        foreach ($inRange as $item) {
            if ($item->globalOrder > (int) $pointer->position()->__toString()) {
                $item->handledAt[] = $this->globalHandleOrder++;

                return $pointer->moveTo((string) $item->globalOrder);
            }
        }

        return $pointer;
    }

    public function totalItems(): int
    {
        return count($this->items);
    }

    public function handledPointersCount(): int
    {
        return $this->handledPointersCount;
    }

    public function allItemsWereHandled(?string &$message = null): bool
    {
        foreach ($this->items as $item) {
            if (0 === count($item->handledAt)) {
                $message = "Item $item->name with global order $item->globalOrder was not handled";

                return false;
            }
        }

        $message = 'All items were handled';

        return true;
    }

    public function allItemsWereNotHandled(?string &$message = null): bool
    {
        foreach ($this->items as $item) {
            if (0 !== count($item->handledAt)) {
                $message = "Item $item->name with global order $item->globalOrder was handled";

                return false;
            }
        }

        $message = 'All items were not handled';

        return true;
    }

    public function allItemsWereHandledOnlyOnce(?string &$message = null): bool
    {
        foreach ($this->items as $item) {
            if (1 !== count($item->handledAt)) {
                $message = sprintf('Item %s with global order %d was handled more than once (%s)', $item->name, $item->globalOrder, implode(', ', $item->handledAt));

                return false;
            }
        }

        $message = 'All items were handled only once';

        return true;
    }

    public function allItemsWereHandledInOrder(?string &$message = null): bool
    {
        $lastHandledByName = [];

        foreach ($this->items as $item) {
            if (1 !== count($item->handledAt)) {
                $message = sprintf('Item %s with global order %d was handled more than once (%s)', $item->name, $item->globalOrder, implode(', ', $item->handledAt));

                return false;
            }

            if (!array_key_exists($item->name, $lastHandledByName)) {
                $lastHandledByName[$item->name] = $item->handledAt[0];
                continue;
            }

            if ($lastHandledByName[$item->name] >= $item->handledAt[0]) {
                $message = sprintf('Item %s with global order %d was handled before %s', $item->name, $item->globalOrder, $lastHandledByName[$item->name]);

                return false;
            }
        }

        $message = 'All items were handled in order';

        return true;
    }

    public function merge(PartitionableCollection $collection): void
    {
        foreach ($collection->items as $item) {
            $this->mergeItem($item);
        }

        $this->globalAddOrder += $collection->globalAddOrder;
        $this->globalHandleOrder += $collection->globalHandleOrder;
        $this->handledPointersCount += $collection->handledPointersCount;
    }

    private function mergeItem(PartitionableItem $item): void
    {
        $localItem = $this->items[$item->globalOrder] ?? null;

        if (null === $localItem) {
            throw new \RuntimeException("Item with global order {$item->globalOrder} does not exist in the collection.");
        }

        if ($localItem->hash !== $item->hash) {
            throw new \RuntimeException("Item with global order {$item->globalOrder} has a different partition than the one in the collection.");
        }

        if ($localItem->name !== $item->name) {
            throw new \RuntimeException("Item with global order {$item->globalOrder} has a different name than the one in the collection.");
        }

        $localItem->handledAt = array_merge($localItem->handledAt, $item->handledAt);

        $this->items[$item->globalOrder] = $localItem;
    }

    public function toArray(): array
    {
        return [
            'items' => array_map(fn (PartitionableItem $item) => $item->toArray(), $this->items),
            'handledPointersCount' => $this->handledPointersCount,
            'globalAddOrder' => $this->globalAddOrder,
            'globalHandleOrder' => $this->globalHandleOrder,
        ];
    }

    public static function fromArray(array $data): self
    {
        $collection = new self();
        $items = array_map(fn (array $item) => PartitionableItem::fromArray($item), $data['items']);
        $collection->handledPointersCount = $data['handledPointersCount'];
        $collection->globalAddOrder = $data['globalAddOrder'];
        $collection->globalHandleOrder = $data['globalHandleOrder'];

        foreach ($items as $item) {
            $collection->items[$item->globalOrder] = $item;
        }

        return $collection;
    }
}
