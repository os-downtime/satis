<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

final readonly class Retry
{
    public static function untilSuccess(int $times, string $errorMessage, \Closure $action): mixed
    {
        $count = 0;
        do {
            /** @var RetryAwareResult $result */
            $result = $action();

            if ($result->isSuccessful) {
                return $result->result;
            }

            if ($result->retryAfterSeconds > 0) {
                sleep($result->retryAfterSeconds);
            }

            ++$count;
        } while ($count < $times);

        throw new \RuntimeException($errorMessage);
    }
}
