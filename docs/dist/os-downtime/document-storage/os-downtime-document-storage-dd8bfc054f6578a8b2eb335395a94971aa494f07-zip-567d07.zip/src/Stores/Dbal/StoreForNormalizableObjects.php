<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use OsDownTime\ExtendedPhp\Normalization\Normalizable;
use OsDownTime\ExtendedPhp\Normalization\NormalizableWithVersion;

final readonly class StoreForNormalizableObjects extends BaseStore
{
    private const string ID_COLUMN_NAME = 'id';
    private const string VERSION_COLUMN_NAME = 'version';
    public const string CONTENT_COLUMN_NAME = 'content';

    public function __construct(Connection $connection, private string $normalizableObjectType)
    {
        parent::__construct($connection, $this->normalizableObjectType);
    }

    /**
     * @throws Exception
     */
    public function add(string $id, Normalizable $object): void
    {
        $normalized = $object->normalize();

        $this->connection->insert(
            $this->tableName,
            [
                self::ID_COLUMN_NAME => $id,
                self::CONTENT_COLUMN_NAME => json_encode($normalized),
                self::VERSION_COLUMN_NAME => $normalized['_version'] + 1,
            ]
        );
    }

    public function get(string $id): ?Normalizable
    {
        $retrieved = $this->connection->fetchAssociative(
            sprintf('SELECT * FROM %s WHERE %s = :sid', $this->tableName, self::ID_COLUMN_NAME),
            ['sid' => $id],
        );

        if (false === $retrieved) {
            return null;
        }

        return $this->normalizableObjectType::denormalize(
            array_merge(
                json_decode($retrieved[self::CONTENT_COLUMN_NAME], true),
                [NormalizableWithVersion::VERSION_KEY => $retrieved[self::VERSION_COLUMN_NAME]],
            )
        );
    }

    public function update(string $id, Normalizable $object): void
    {
        $normalized = $object->normalize();

        $qb = $this->connection->createQueryBuilder()
            ->update($this->tableName)
            ->set(self::CONTENT_COLUMN_NAME, ':sc')
            ->setParameter('sc', json_encode($normalized))
            ->set(self::VERSION_COLUMN_NAME, self::VERSION_COLUMN_NAME.' + 1')
            ->where(self::ID_COLUMN_NAME.' = :sid')
            ->setParameter('sid', $id);

        if ($object instanceof NormalizableWithVersion) {
            $qb->andWhere(self::VERSION_COLUMN_NAME.' = :vl')
                ->setParameter('vl', $normalized[NormalizableWithVersion::VERSION_KEY]);
        }

        $numberOfUpdatedRows = $qb->executeStatement();

        if (0 === $numberOfUpdatedRows) {
            throw new VersionLockException();
        }
    }

    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void
    {
        if ($schema->hasTable($this->tableName)) {
            return;
        }

        if (!$isSameDatabase($this->connection->executeStatement(...))) {
            return;
        }

        $table = $schema->createTable($this->tableName);
        $table->addColumn(self::ID_COLUMN_NAME, Types::STRING);
        $table->addColumn(self::VERSION_COLUMN_NAME, Types::INTEGER, ['default' => 1]);
        $table->addColumn(self::CONTENT_COLUMN_NAME, Types::JSON);
        $table->setPrimaryKey([self::ID_COLUMN_NAME]);
    }
}
