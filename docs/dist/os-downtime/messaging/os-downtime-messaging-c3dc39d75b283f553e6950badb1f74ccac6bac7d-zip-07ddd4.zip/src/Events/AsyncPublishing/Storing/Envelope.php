<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Storing;

final readonly class Envelope
{
    private Stamps $stamps;

    public function __construct(
        public string $streamName,
        public int $streamVersion,
        public string $serializedEvent,
        public string $eventType,
        Stamp ...$stamps,
    ) {
        $this->stamps = new Stamps(...$stamps);
    }

    /**
     * @return Stamp[]
     */
    public function stamps(): iterable
    {
        return $this->stamps->all();
    }

    public function stampValue(string $name): string
    {
        return $this->stamps->stampValue($name);
    }
}
