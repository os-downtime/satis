<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

use Psr\Log\LoggerInterface;

final class RelayWorker
{
    public function __construct(private readonly Relay $relay, private readonly LoggerInterface $logger, private bool $shouldStop = false)
    {
    }

    public function start(WorkerOptions $options): void
    {
        $this->shouldStop = false;

        $this->relay->batcherFor(
            $options->workerId,
            $options->eventHandlerId,
            function (RelayBatcher $batcher) use ($options) {
                $totalRelayed = 0;

                do {
                    $batchResult = $batcher->nextBatch($options->batchSize);
                    $totalRelayed += $batchResult->eventsRelayed;

                    if ($batchResult->eventsRelayed < $options->batchSize) {
                        $this->onEmptyQueue($options->secondsToSleepOnEmptyQueue);
                    }

                    if ($options->maxEventsToRelay > 0 && $totalRelayed >= $options->maxEventsToRelay) {
                        $this->onMaxEventsRelayed();
                    }
                } while (!$this->shouldStop && $batchResult->canContinue);
            }
        );
    }

    private function onEmptyQueue(int $secondsToSleep): void
    {
        $this->logger->debug('Queue is empty, waiting for new events to relay...');
        if ($secondsToSleep > 0) {
            sleep($secondsToSleep);
        }
    }

    private function onMaxEventsRelayed(): void
    {
        $this->logger->debug('Max events to relay reached, stopping...');
        $this->stop();
    }

    public function stop(): void
    {
        $this->logger->debug('Stopping relay worker...');
        $this->shouldStop = true;
    }
}
