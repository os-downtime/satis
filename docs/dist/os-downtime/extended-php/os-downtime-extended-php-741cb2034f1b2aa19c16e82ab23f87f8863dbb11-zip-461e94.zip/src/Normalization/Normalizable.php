<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Normalization;

interface Normalizable
{
    public function normalize(): array;

    public static function denormalize(array $normalized): self;
}
