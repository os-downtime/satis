<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils\PartitionableCollection;

final readonly class CollectionBuilder
{
    public static function populateWith(int $totalNames, int $itemsPerName, int $totalHashes, int $rangeMinHash = 0, int $rangeMaxHash = PHP_INT_MAX): PartitionableCollection
    {
        $hashingFunction = new UniformHashing($rangeMinHash, $rangeMaxHash, $totalHashes);

        $collection = new PartitionableCollection();

        for ($itemsIndex = 0; $itemsIndex < $itemsPerName; ++$itemsIndex) {
            for ($nameIndex = 0; $nameIndex < $totalNames; ++$nameIndex) {
                $name = "name-$nameIndex";
                $collection->add(new PartitionableItem(
                    $hashingFunction->hash($name),
                    0,
                    $name,
                ));
            }
        }

        return $collection;
    }
}
