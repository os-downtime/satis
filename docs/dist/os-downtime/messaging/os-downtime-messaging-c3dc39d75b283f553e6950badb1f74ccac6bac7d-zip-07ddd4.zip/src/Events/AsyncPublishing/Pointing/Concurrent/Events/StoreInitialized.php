<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class StoreInitialized implements StoreEvent
{
    public function __construct(public string $eventHandlerId, public int $initializedPointersCount)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::StoreInitialized;
    }
}
