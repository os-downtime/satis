<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Events;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Schema;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitializationFailed;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitializationNeeded;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitialized;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\HandlerWorkerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Tests\Utils\DbalConnectionBuilder;
use OsDownTime\Messaging\Tests\Utils\OpenToConfigurationStore;
use OsDownTime\Messaging\Tests\Utils\StoreTestCase;
use PHPUnit\Framework\Attributes\CoversClass;

#[CoversClass(CooperatingWorkersStore::class)]
#[CoversClass(HandlerWorkerContext::class)]
final class TwoWorkersTest extends StoreTestCase
{
    private OpenToConfigurationStore $firstStore;
    private OpenToConfigurationStore $secondStore;
    private string $tenant = 'someTenant';

    /**
     * @throws Exception
     */
    public function setUp(): void
    {
        $toRecreate = new Schema();

        $this->firstStore = new OpenToConfigurationStore(DbalConnectionBuilder::build());
        $this->firstStore->configureSchema($toRecreate);

        $this->secondStore = new OpenToConfigurationStore(DbalConnectionBuilder::build());
        $this->secondStore->configureSchema($toRecreate);

        $this->recreateSchema($toRecreate);
    }

    public function testOnlyOneWorkerCanInitializeStore(): void
    {
        $this->firstStore->on(StoreInitializationNeeded::class, function () {
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {});
        });

        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {});

        $this->assertContains(StoreInitialized::class, $this->secondStore->typesOfPublishedEvents());

        $this->assertContains(StoreInitializationFailed::class, $this->firstStore->typesOfPublishedEvents());
    }
}
