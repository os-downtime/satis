<?php

declare(strict_types=1);

namespace OsDownTime\Common\Domain;

abstract readonly class ValueObject implements \Stringable
{
}
