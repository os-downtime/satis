<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class WorkerTickedToStop implements StoreEvent
{
    public function __construct(public string $workerId, public string $stopReason, public ?int $lostPointerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::WorkerTickedToStop;
    }
}
