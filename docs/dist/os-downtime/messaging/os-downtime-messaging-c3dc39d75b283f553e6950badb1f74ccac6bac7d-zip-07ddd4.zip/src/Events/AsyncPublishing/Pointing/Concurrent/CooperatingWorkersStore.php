<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use OsDownTime\ExtendedPhp\Time\Clock;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\ConfigurationLoader;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\StoreConfiguration;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\CollectingEventDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerSplit;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerSplitRequested;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitializationFailed;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitializationNeeded;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreInitialized;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\DbalLockablePointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\Events\PointerToSplitGrabbed;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\LockablePointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\DbalWorkerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\Worker;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\WorkerState;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerStore;

final readonly class CooperatingWorkersStore implements PointerStore
{
    private StoreConfiguration $configuration;

    public function __construct(
        private DbalLockablePointerStore $pointerStore,
        private DbalWorkerStore $workerStore,
        private Clock $clock,
        private CollectingEventDispatcher $dispatcher,
        private ContextFactory $contextFactory,
        ConfigurationLoader $configurationLoader,
    ) {
        $this->configuration = $configurationLoader->load();
    }

    public function usingContextFor(string $workerId, string $eventHandlerId, \Closure $contextHandler): void
    {
        $this->initialize($eventHandlerId);

        $this->executeChores($eventHandlerId);

        $this->signWorkerIn($eventHandlerId, $workerId);

        $contextHandler($this->contextFactory->contextFor($eventHandlerId, $workerId));

        $this->signWorkerOut($eventHandlerId, $workerId);
    }

    private function initialize(string $eventHandlerId): void
    {
        if (!$this->isStoreAlreadyInitialized($eventHandlerId)) {
            $this->dispatcher->dispatch(new StoreInitializationNeeded($eventHandlerId));
            $this->initializeStore($eventHandlerId);
        }
    }

    private function isStoreAlreadyInitialized(string $eventHandlerId): bool
    {
        return $this->pointerStore->hasPointersFor($eventHandlerId);
    }

    private function initializeStore(string $eventHandlerId): void
    {
        $defaultPointer = LockablePointer::defaultFor($eventHandlerId, '');
        $all = [$defaultPointer];

        for ($i = 0; $i < $this->configuration->initialPointersCount - 1; ++$i) {
            $all[] = $all[$i]->split($this->clock->now());
        }

        if ($this->pointerStore->insert(...$all)) {
            $this->dispatcher->dispatch(new StoreInitialized($eventHandlerId, count($all)));
        } else {
            $this->dispatcher->dispatch(new StoreInitializationFailed($eventHandlerId));
        }
    }

    /**
     * @throws \DateMalformedStringException
     * @throws \Throwable
     */
    private function executeChores(string $eventHandlerId): void
    {
        $this->signOutStaleWorkersIfAny($eventHandlerId);

        $this->flagStaleWorkersIfAny($eventHandlerId);

        // TODO: merge pointers and remove workers
    }

    private function signWorkerIn(string $eventHandlerId, string $workerId): void
    {
        $needsPointerSplit = $this->doSignIn($eventHandlerId, $workerId)->result;

        if (!$needsPointerSplit) {
            return;
        }

        if (true === $this->tryReplaceSignedOutWorker($eventHandlerId, $workerId)->result) {
            return;
        }

        Retry::untilSuccess(
            $this->configuration->timesToConsiderStuck,
            "I'm stuck splitting a pointer",
            fn () => $this->splitPointerForNewWorker($eventHandlerId),
        );
    }

    /**
     * @return RetryAwareResult<bool> Needs a pointer split
     *
     * @throws \Throwable
     */
    private function doSignIn(string $eventHandlerId, string $workerId): RetryAwareResult
    {
        $result = $this->workerStore->grabById($eventHandlerId, $workerId, function (?Worker $worker) use ($eventHandlerId, $workerId) {
            if (null === $worker) {
                if ($this->workerStore->insert(Worker::signIn($workerId, $eventHandlerId, $this->clock->now(), $this->configuration->maxPointerLostBeforeStopping, $eventToCollect))) {
                    $this->dispatcher->collectEvent($eventToCollect);

                    return RetryAwareResult::success(true);
                }

                return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
            }

            $needsPointerSplit = $worker->signBackIn($this->clock->now(), $eventToCollect);
            $this->dispatcher->collectEvent($eventToCollect);

            return RetryAwareResult::success($needsPointerSplit);
        });

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }

    /**
     * @throws \DateMalformedStringException
     * @throws \Throwable
     */
    private function signOutStaleWorkersIfAny(string $eventHandlerId): void
    {
        $this->workerStore->grabOneStaleWithoutTicksAfter(
            $eventHandlerId,
            $this->clock->now()->modify("- {$this->configuration->secondsToSignOutStaleWorker} seconds"),
            function (?Worker $staleWorker) {
                if (null === $staleWorker) {
                    return RetryAwareResult::success();
                }

                $staleWorker->signOut($eventToCollect);
                $this->dispatcher->collectEvent($eventToCollect);

                return RetryAwareResult::success();
            }
        );

        $this->dispatcher->dispatchCollectedEvents();
    }

    /**
     * @throws \DateMalformedStringException
     * @throws \Throwable
     */
    private function flagStaleWorkersIfAny(string $eventHandlerId): void
    {
        $this->workerStore->grabOneWithoutTicksAfter(
            $eventHandlerId,
            $this->clock->now()->modify("- {$this->configuration->secondsToConsiderWorkerStale} seconds"),
            function (?Worker $staleWorker) {
                if (null === $staleWorker) {
                    return RetryAwareResult::success();
                }

                $staleWorker->flagStale($eventToCollect);

                $this->dispatcher->collectEvent($eventToCollect);

                return RetryAwareResult::success();
            }
        );

        $this->dispatcher->dispatchCollectedEvents();
    }

    /**
     * @return RetryAwareResult<bool> Was a worker replaced
     */
    private function tryReplaceSignedOutWorker(string $eventHandlerId, string $workerId): RetryAwareResult
    {
        $result = $this->workerStore->grabWorkerByState($eventHandlerId, WorkerState::SIGNED_OUT, function (?Worker $signedOutWorker) use ($workerId) {
            if (null === $signedOutWorker) {
                return RetryAwareResult::success(false);
            }

            $signedOutWorker->replaceSignedOut($workerId, $eventToCollect);

            $this->dispatcher->collectEvent($eventToCollect);

            return RetryAwareResult::success(true);
        });

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }

    private function signWorkerOut(string $eventHandlerId, string $workerId): void
    {
        Retry::untilSuccess(
            $this->configuration->timesToConsiderStuck,
            "I'm stuck signing out",
            fn () => $this->signOut($eventHandlerId, $workerId),
        );
    }

    /**
     * @return RetryAwareResult<void>
     *
     * @throws \Throwable
     */
    private function signOut(string $eventHandlerId, string $workerId): RetryAwareResult
    {
        $result = $this->workerStore->grabById($eventHandlerId, $workerId, function (?Worker $worker) {
            if (null === $worker) {
                return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
            }

            $worker->signOut($eventToCollect);
            $this->dispatcher->collectEvent($eventToCollect);

            return RetryAwareResult::success();
        });

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }

    private function splitPointerForNewWorker(string $eventHandlerId): RetryAwareResult
    {
        $result = $this->pointerStore->grabBiggestNotSplitForLonger(
            $eventHandlerId,
            function (?LockablePointer $pointer, ?array &$newPointers = null) {
                if (null === $pointer) {
                    return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
                }

                $this->dispatcher->dispatch(new PointerToSplitGrabbed($pointer->minHash, $pointer->isFree()));

                if ($pointer->isFree()) {
                    $newPointer = $pointer->split($this->clock->now());
                    $newPointers = [$newPointer];

                    $this->dispatcher->collectEvent(new PointerSplit($pointer->minHash, [$newPointer->minHash]));

                    return RetryAwareResult::success();
                }

                $pointer->requestSplit($this->clock->now());

                $this->dispatcher->collectEvent(new PointerSplitRequested($pointer->minHash));

                return $pointer->minHash;
            }
        );

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }
}
