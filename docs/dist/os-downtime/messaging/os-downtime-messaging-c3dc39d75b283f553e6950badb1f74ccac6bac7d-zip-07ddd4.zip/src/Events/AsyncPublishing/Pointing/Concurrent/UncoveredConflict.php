<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

final class UncoveredConflict extends \RuntimeException
{
    public static function resizedWhileLocked(int $pointerId, int $lockedSize, int $storedSize): self
    {
        return new self("Pointer $pointerId was resized while locked. Locked size: $lockedSize, stored size: $storedSize");
    }

    public static function grabFailedFor(string $reason): self
    {
        return new self("Failed to grab for $reason");
    }

    public static function unexpectedStateAtSignOut(string $workerId, string $state): self
    {
        return new self("Unexpected state at sign out [$state] for worker $workerId");
    }

    public static function inactiveWorkerFlaggedStale(string $workerId): self
    {
        return new self("Inactive worker $workerId flagged stale");
    }

    public static function signedInWorkerReplaced(string $workerId): self
    {
        return new self("Signed in worker $workerId replaced");
    }
}
