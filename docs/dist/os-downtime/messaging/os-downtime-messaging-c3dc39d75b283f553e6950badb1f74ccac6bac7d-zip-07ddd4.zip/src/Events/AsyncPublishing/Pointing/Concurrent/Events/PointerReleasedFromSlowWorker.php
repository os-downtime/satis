<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class PointerReleasedFromSlowWorker implements StoreEvent
{
    public function __construct(public int $pointerId, public string $slowWorkerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::PointerReleasedFromSlowWorker;
    }
}
