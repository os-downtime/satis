<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Doctrine\DBAL\Query\ForUpdate\ConflictResolutionMode;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use OsDownTime\DocumentStorage\Stores\Dbal\AbleToConfigureSchema;
use OsDownTime\DocumentStorage\Stores\Dbal\SchemaConfigurator;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\RetryAwareResult;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\UncoveredConflict;

final readonly class DbalWorkerStore implements SchemaConfigurator, AbleToConfigureSchema
{
    private const string WORKERS_TABLE_NAME = 'workers';

    public function __construct(private Connection $connection)
    {
    }

    public function configurator(): SchemaConfigurator
    {
        return $this;
    }

    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void
    {
        if ($schema->hasTable(self::WORKERS_TABLE_NAME)) {
            return;
        }

        if (!$isSameDatabase($this->connection->executeStatement(...))) {
            return;
        }

        $table = $schema->createTable(self::WORKERS_TABLE_NAME);

        $table->addColumn('id', Types::STRING);
        $table->addColumn('tenant', Types::STRING);
        $table->addColumn('state', Types::STRING);
        $table->addColumn('last_tick_at', Types::DATETIMETZ_IMMUTABLE, ['default' => null, 'notnull' => false]);
        $table->addColumn('times_pointer_lost', Types::INTEGER, ['default' => 0]);
        $table->addColumn('max_pointer_lost', Types::INTEGER, ['default' => null, 'notnull' => false]);
        $table->addColumn('version', Types::BIGINT, ['default' => 1]);

        $table->setPrimaryKey(['id', 'tenant']);
    }

    private function hydrateWorker(array $row): Worker
    {
        return new Worker(
            id: $row['id'],
            tenant: $row['tenant'],
            state: WorkerState::from($row['state']),
            lastTickAt: null !== $row['last_tick_at'] ? new \DateTimeImmutable($row['last_tick_at']) : null,
            timesPointerLost: (int) $row['times_pointer_lost'],
            version: (int) $row['version'],
            maxTimesPointerLost: (int) $row['max_pointer_lost'],
        );
    }

    public function insert(Worker ...$workers): bool
    {
        $params = $types = [];

        foreach ($workers as $worker) {
            $params[] = $worker->id;
            $params[] = $worker->state->value;
            $params[] = $worker->tenant;
            $params[] = $worker->lastTickAt;
            $params[] = $worker->timesPointerLost;
            $params[] = $worker->maxTimesPointerLost;
            $params[] = $worker->version;

            array_push(
                $types,
                Types::STRING,
                Types::STRING,
                Types::STRING,
                Types::DATETIMETZ_IMMUTABLE,
                Types::INTEGER,
                Types::INTEGER,
                Types::INTEGER,
            );
        }

        try {
            $affectedRows = $this->connection->executeStatement(
                sprintf(
                    'INSERT INTO %s (id, state, tenant, last_tick_at, times_pointer_lost, max_pointer_lost, version) VALUES %s',
                    self::WORKERS_TABLE_NAME,
                    implode(', ', array_map(static fn (Worker $worker): string => '(?, ?, ?, ?, ?, ?, ?)', $workers)),
                ),
                $params,
                $types,
            );
        } catch (UniqueConstraintViolationException) {
            return false;
        }

        return $affectedRows === count($workers);
    }

    public function grabById(string $tenant, string $workerId, \Closure $grabber): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('w.*')
            ->from(self::WORKERS_TABLE_NAME, 'w')
            ->where('w.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('w.id = :sid')
            ->setParameter('sn', $tenant)
            ->setParameter('sid', $workerId)
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $worker = null;

        if (count($rows) > 0) {
            $worker = $this->hydrateWorker($rows[0]);
        }

        try {
            $innerResult = $grabber($worker);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $updateSuccess = null;

        if (null !== $worker) {
            $updateSuccess = $this->update($worker);
        }

        if (false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('worker by id');
        }

        $this->connection->commit();

        return $innerResult;
    }

    public function grabWorkerByState(string $tenant, WorkerState $state, \Closure $grabber): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('w.*')
            ->from(self::WORKERS_TABLE_NAME, 'w')
            ->where('w.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('w.state = :ss')
            ->setParameter('ss', $state->value)
            ->setParameter('sn', $tenant)
            ->orderBy('w.last_tick_at', 'ASC NULLS FIRST')
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $worker = null;

        if (count($rows) > 0) {
            $worker = $this->hydrateWorker($rows[0]);
        }

        try {
            $innerResult = $grabber($worker);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $updateSuccess = null;

        if (null !== $worker) {
            $updateSuccess = $this->update($worker);
        }

        if (false === $updateSuccess) {
            $this->connection->rollBack();
            throw UncoveredConflict::grabFailedFor('signed out worker');
        }

        $this->connection->commit();

        return $innerResult;
    }

    private function update(Worker $worker): bool
    {
        $numberOfUpdatedRows = $this->connection->createQueryBuilder()
            ->update(self::WORKERS_TABLE_NAME)
            ->set('state', ':st')
            ->setParameter('st', $worker->state->value)
            ->set('last_tick_at', ':lt')
            ->setParameter('lt', $worker->lastTickAt, Types::DATETIMETZ_IMMUTABLE)
            ->set('times_pointer_lost', ':tl')
            ->setParameter('tl', $worker->timesPointerLost)
            ->set('version', 'version + 1')
            ->where('id = :id')
            ->setParameter('id', $worker->id)
            ->andWhere('tenant = :sn')
            ->setParameter('sn', $worker->tenant)
            ->andWhere('version = :cVl')
            ->setParameter('cVl', $worker->version)
            ->executeStatement();

        if (1 === $numberOfUpdatedRows) {
            ++$worker->version;

            return true;
        }

        return false;
    }

    public function grabOneWithoutTicksAfter(string $tenant, \DateTimeImmutable $lastTickCap, \Closure $grabber): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('w.*')
            ->from(self::WORKERS_TABLE_NAME, 'w')
            ->where('w.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('w.state = :ss')
            ->andWhere('w.last_tick_at <= :lt')
            ->setParameter('ss', WorkerState::ACTIVE->value)
            ->setParameter('sn', $tenant)
            ->setParameter('lt', $lastTickCap, Types::DATETIMETZ_IMMUTABLE)
            ->orderBy('w.last_tick_at', 'ASC NULLS FIRST')
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $worker = null;

        if (count($rows) > 0) {
            $worker = $this->hydrateWorker($rows[0]);
        }

        try {
            $innerResult = $grabber($worker);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $updateSuccess = null;

        if (null !== $worker) {
            $updateSuccess = $this->update($worker);
        }

        if (false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('worker without ticks');
        }

        $this->connection->commit();

        return $innerResult;
    }

    public function grabOneStaleWithoutTicksAfter(string $tenant, \DateTimeImmutable $lastTickCap, \Closure $grabber): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('w.*')
            ->from(self::WORKERS_TABLE_NAME, 'w')
            ->where('w.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('w.state = :ss')
            ->andWhere('w.last_tick_at <= :lt')
            ->setParameter('ss', WorkerState::STALE->value)
            ->setParameter('sn', $tenant)
            ->setParameter('lt', $lastTickCap, Types::DATETIMETZ_IMMUTABLE)
            ->orderBy('w.last_tick_at', 'ASC NULLS FIRST')
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $worker = null;

        if (count($rows) > 0) {
            $worker = $this->hydrateWorker($rows[0]);
        }

        try {
            $innerResult = $grabber($worker);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $updateSuccess = null;

        if (null !== $worker) {
            $updateSuccess = $this->update($worker);
        }

        if (false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('stale worker without ticks');
        }

        $this->connection->commit();

        return $innerResult;
    }
}
