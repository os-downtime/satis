<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing;

interface PointerStore
{
    public function usingContextFor(string $workerId, string $eventHandlerId, \Closure $contextHandler): void;
}
