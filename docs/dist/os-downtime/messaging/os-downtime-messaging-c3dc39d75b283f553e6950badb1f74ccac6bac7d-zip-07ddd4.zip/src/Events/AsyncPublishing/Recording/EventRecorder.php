<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Recording;

use OsDownTime\Common\Domain\Event;

interface EventRecorder
{
    public function record(Event ...$events): void;
}
