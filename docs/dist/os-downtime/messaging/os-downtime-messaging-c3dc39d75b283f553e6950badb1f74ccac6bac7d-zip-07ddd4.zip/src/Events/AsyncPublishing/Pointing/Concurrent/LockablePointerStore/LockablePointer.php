<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore;

final class LockablePointer
{
    public function __construct(
        public int $minHash,
        public int $maxHash,
        public string $tenant,
        public ?string $request,
        public string $position,
        public int $size,
        public ?string $lockedBy,
        public ?\DateTimeImmutable $lastReleasedAt,
        public ?\DateTimeImmutable $lastLockedAt,
        public ?\DateTimeImmutable $lastSplitAt,
        public int $version,
    ) {
    }

    public static function defaultFor(string $tenant, string $defaultPosition): self
    {
        return new self(
            minHash: 0,
            maxHash: PHP_INT_MAX,
            tenant: $tenant,
            request: null,
            position: $defaultPosition,
            size: PHP_INT_MAX,
            lockedBy: null,
            lastReleasedAt: null,
            lastLockedAt: null,
            lastSplitAt: null,
            version: 1,
        );
    }

    public function split(\DateTimeImmutable $now): self
    {
        $newSize = intdiv($this->maxHash - $this->minHash, 2);

        $tempMax = $this->maxHash;

        $this->maxHash = $this->minHash + $newSize;
        $this->size = $this->maxHash - $this->minHash;
        $this->lastSplitAt = $now;

        $nextMinHash = $this->maxHash + 1;

        return new self(
            minHash: $nextMinHash,
            maxHash: $tempMax,
            tenant: $this->tenant,
            request: $this->request,
            position: $this->position,
            size: $tempMax - $nextMinHash,
            lockedBy: $this->lockedBy,
            lastReleasedAt: $this->lastReleasedAt,
            lastLockedAt: $this->lastLockedAt,
            lastSplitAt: null,
            version: 1,
        );
    }

    public function release(): void
    {
        $this->lockedBy = null;
    }

    public function isFree(): bool
    {
        return null === $this->lockedBy;
    }

    public function lock(string $workerId, \DateTimeImmutable $now): void
    {
        $this->lockedBy = $workerId;
        $this->lastLockedAt = $now;
    }

    public function requestSplit(\DateTimeImmutable $now): void
    {
        $this->request = 'queued-for-split';
        $this->lastSplitAt = $now;
    }

    public function splitRequested(): bool
    {
        return null !== $this->request;
    }

    public function isLocked(): bool
    {
        return null !== $this->lockedBy;
    }
}
