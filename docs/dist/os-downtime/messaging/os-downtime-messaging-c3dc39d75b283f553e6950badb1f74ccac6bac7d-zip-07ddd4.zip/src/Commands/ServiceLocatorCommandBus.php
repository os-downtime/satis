<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Commands;

use OsDownTime\Common\Application\Command;
use OsDownTime\Common\Application\CommandBus;
use Psr\Container\ContainerInterface;

final readonly class ServiceLocatorCommandBus implements CommandBus
{
    public function __construct(private ContainerInterface $locator)
    {
    }

    public function dispatch(Command $command): mixed
    {
        if (!$this->locator->has($command::class)) {
            throw new \RuntimeException(sprintf("No handler found for command '%s'", $command::class));
        }

        return $this->locator->get($command::class)->execute($command);
    }
}
