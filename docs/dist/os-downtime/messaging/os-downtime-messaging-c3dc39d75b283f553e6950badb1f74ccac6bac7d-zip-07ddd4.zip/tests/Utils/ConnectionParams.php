<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils;

final readonly class ConnectionParams
{
    public static function load(string $prefix): array
    {
        $result = self::map($GLOBALS, $prefix);

        if (count($result) > 0) {
            return $result;
        }

        return self::map(getenv(), $prefix);
    }

    private static function map(array $configuration, string $prefix): array
    {
        $parameters = [];

        foreach (
            [
                'dbname',
                'user',
                'password',
                'host',
                'driver',
                'port',
            ] as $parameter
        ) {
            if (!isset($configuration[$prefix.$parameter])) {
                continue;
            }

            $parameters[$parameter] = $configuration[$prefix.$parameter];
        }

        if (isset($parameters['port'])) {
            $parameters['port'] = (int) $parameters['port'];
        }

        return $parameters;
    }
}
