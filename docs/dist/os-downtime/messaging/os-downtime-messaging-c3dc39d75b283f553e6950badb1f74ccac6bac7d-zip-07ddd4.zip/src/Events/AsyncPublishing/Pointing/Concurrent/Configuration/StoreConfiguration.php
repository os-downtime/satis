<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration;

final readonly class StoreConfiguration
{
    public int $secondsToSignOutStaleWorker;

    public function __construct(
        public int $initialPointersCount,
        public int $secondsToConsiderWorkerStale,
        public int $timesToConsiderStuck,
        public int $maxTransactionDurationInSeconds,
        public int $workingTimeInSeconds,
        public int $maxPointerLostBeforeStopping,
        int $secondsToSignOutStaleWorker = 0,
    ) {
        if (0 === $secondsToSignOutStaleWorker) {
            $this->secondsToSignOutStaleWorker = $secondsToConsiderWorkerStale * 2;
        }
    }

    public static function default(): self
    {
        return new self(3, 120, 3, 0, 5, 3);
    }
}
