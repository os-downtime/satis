<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events;

use OsDownTime\Common\Application\EventHandler as CommonEventHandler;

interface EventHandler extends CommonEventHandler
{
    /**
     * @return string[];
     */
    public static function handledEvents(): array;
}
