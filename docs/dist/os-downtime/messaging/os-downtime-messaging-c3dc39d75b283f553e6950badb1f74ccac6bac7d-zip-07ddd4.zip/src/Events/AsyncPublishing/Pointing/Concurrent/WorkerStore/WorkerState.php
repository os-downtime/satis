<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore;

enum WorkerState: string
{
    case ACTIVE = 'active';
    case SIGNED_OUT = 'signed_out';
    case REPLACED = 'replaced';
    case STALE = 'stale';
}
