<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Commands;

use OsDownTime\Common\Application\Command;

trait CommandHandlerTrait
{
    public function execute(Command $command): mixed
    {
        $commandIndex = array_search($command::class, self::handledCommands());
        $methodName = sprintf('execute%s', $commandIndex);

        return $this->{$methodName}($command);
    }

    abstract public static function handledCommands(): array;
}
