<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Recording;

use OsDownTime\Common\Domain\Event;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\Envelope;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\PartitionedEventStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\Stamp;
use Symfony\Component\Serializer\SerializerInterface;

final readonly class StoreBasedEventRecorder implements EventRecorder
{
    public const string EVENT_TYPE_STAMP_NAME = 'event_type';

    public function __construct(private PartitionedEventStore $store, private SerializerInterface $serializer)
    {
    }

    public function record(Event ...$events): void
    {
        $this->store->append(...array_map(
            fn (Event $event) => new Envelope(
                $event->aggregateId(),
                $event->aggregateVersion(),
                $this->serializer->serialize($event, 'json'),
                $event::class,
                new Stamp(self::EVENT_TYPE_STAMP_NAME, $event::class)
            ),
            $events
        ));
    }
}
