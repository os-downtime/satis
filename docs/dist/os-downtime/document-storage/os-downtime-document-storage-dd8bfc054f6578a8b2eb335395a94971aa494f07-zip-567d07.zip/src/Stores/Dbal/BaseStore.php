<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

use Doctrine\DBAL\Connection;

abstract readonly class BaseStore implements SchemaConfigurator
{
    protected string $tableName;

    public function __construct(protected Connection $connection, string $normalizableObjectType)
    {
        $this->tableName = $this->typeToTableName($normalizableObjectType);
    }

    protected function typeToTableName(string $fQCN): string
    {
        $className = substr($fQCN, strrpos($fQCN, '\\') + 1);

        return $this->underscore($className);
    }

    private function underscore(string $className): string
    {
        $className = preg_replace('/(?<=[a-z0-9])([A-Z])/', '_$1', $className);

        return strtolower($className);
    }
}
