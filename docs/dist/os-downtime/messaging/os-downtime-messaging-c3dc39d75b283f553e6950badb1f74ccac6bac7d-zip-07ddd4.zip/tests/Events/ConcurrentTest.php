<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Events;

use Doctrine\DBAL\Schema\Schema;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\HandlerWorkerContext;
use OsDownTime\Messaging\Tests\Utils\ConnectionParams;
use OsDownTime\Messaging\Tests\Utils\DbalConnectionBuilder;
use OsDownTime\Messaging\Tests\Utils\OpenToConfigurationStore;
use OsDownTime\Messaging\Tests\Utils\PartitionableCollection\PartitionableCollection;
use OsDownTime\Messaging\Tests\Utils\StoreTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use Symfony\Component\Process\Process;

#[CoversClass(CooperatingWorkersStore::class)]
#[CoversClass(HandlerWorkerContext::class)]
final class ConcurrentTest extends StoreTestCase
{
    protected function setUp(): void
    {
        $schema = new Schema();

        $disposable = new OpenToConfigurationStore(DbalConnectionBuilder::build());

        $disposable->configureSchema($schema);

        $this->recreateSchema($schema);
    }

    public function testTwoCompetingWorkers(): void
    {
        $connectionParams = ConnectionParams::load('db_');

        $cliCommandArguments = [
            'tenant' => 'someEventHandlerId',
            'initialPointers' => 4,
            'storeStaleSeconds' => 120,
            'collectionTotalHashes' => 10,
            'collectionTotalNames' => 10,
            'collectionItemsPerName' => 3,
            'simulatedHandlingTime' => 50000,
            'workTimeSeconds' => 2,
            'maxPointerLost' => 3,
        ];

        // currently ignoring the simulated handling time (assuming it will be less that a second)
        $timeout = $cliCommandArguments['collectionTotalNames'] * $cliCommandArguments['collectionItemsPerName'] * $cliCommandArguments['initialPointers'];

        $process1 = new Process(['bin/console', 'app:handle:collection', 'worker1', ...array_values($cliCommandArguments)]);
        $process1->setTimeout($timeout);
        $process1->start(null, $connectionParams);

        $process2 = new Process(['bin/console', 'app:handle:collection', 'worker2', ...array_values($cliCommandArguments)]);
        $process2->setTimeout($timeout);
        $process2->start(null, $connectionParams);

        $process1->wait();
        $process2->wait();

        $this->assertTrue($process1->isSuccessful());
        $this->assertTrue($process2->isSuccessful());

        $collection1 = PartitionableCollection::fromArray(json_decode($process1->getOutput(), true));

        self::assertFalse($collection1->allItemsWereHandled($message), $message);
        self::assertFalse($collection1->allItemsWereNotHandled($message), $message);

        $collection2 = PartitionableCollection::fromArray(json_decode($process2->getOutput(), true));

        self::assertFalse($collection2->allItemsWereHandled($message), $message);
        self::assertFalse($collection2->allItemsWereNotHandled($message), $message);

        $collection1->merge($collection2);

        self::assertTrue($collection1->allItemsWereHandled($message), $message);
        self::assertTrue($collection1->allItemsWereHandledOnlyOnce($message), $message);
        self::assertTrue($collection1->allItemsWereHandledInOrder($message), $message);
    }
}
