<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\Events;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\EventName;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;

final readonly class StalePointerRetrieved implements StoreEvent
{
    public function __construct(public int $minHash, public string $staleWorkerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::StalePointerRetrieved;
    }
}
