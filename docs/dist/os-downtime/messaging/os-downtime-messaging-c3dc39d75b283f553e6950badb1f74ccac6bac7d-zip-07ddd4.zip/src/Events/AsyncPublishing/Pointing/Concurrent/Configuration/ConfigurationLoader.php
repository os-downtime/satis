<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration;

interface ConfigurationLoader
{
    public function load(): StoreConfiguration;
}
