<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing;

final readonly class Position implements \Stringable
{
    private function __construct(private string $value)
    {
    }

    public static function start(): Position
    {
        return new self('');
    }

    public static function create(?string $rawValue): Position
    {
        return new self($rawValue ?? '');
    }

    public function __toString(): string
    {
        return $this->value;
    }
}
