# document-storage
An attempt at a simplified storage solution
