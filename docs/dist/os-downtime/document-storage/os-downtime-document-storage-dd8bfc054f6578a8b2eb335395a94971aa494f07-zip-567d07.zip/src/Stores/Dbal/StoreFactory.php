<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

use Doctrine\DBAL\Connection;
use Symfony\Component\Serializer\SerializerInterface;

final readonly class StoreFactory
{
    public function buildStoreForNormalizableObjects(Connection $connection, string $normalizableObjectType): StoreForNormalizableObjects
    {
        return new StoreForNormalizableObjects($connection, $normalizableObjectType);
    }

    public function buildStoreForSerializableObjects(Connection $connection, string $serializableObjectType, SerializerInterface $serializer): StoreForSerializableObjects
    {
        return new StoreForSerializableObjects($connection, $serializableObjectType, $serializer);
    }
}
