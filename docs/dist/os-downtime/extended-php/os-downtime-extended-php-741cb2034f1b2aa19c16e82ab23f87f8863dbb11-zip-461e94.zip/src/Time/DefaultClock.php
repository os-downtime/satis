<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Time;

final readonly class DefaultClock implements Clock
{
    public function now(): \DateTimeImmutable
    {
        return new \DateTimeImmutable();
    }
}
