<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Events;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Schema;
use OsDownTime\ExtendedPhp\Time\TimeTravelerClock;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\AlreadySignedOutWorkerStopped;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerReleasedFromSlowWorker;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerRetrieved;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StaleWorkerTickedToContinue;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerFlaggedAsStale;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerSignedOut;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerTickedToContinue;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerTickedToStop;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\HandlerWorkerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerUnableToContinue;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Tests\Utils\DbalConnectionBuilder;
use OsDownTime\Messaging\Tests\Utils\OpenToConfigurationStore;
use OsDownTime\Messaging\Tests\Utils\StoreTestCase;
use PHPUnit\Framework\Attributes\CoversClass;

#[CoversClass(CooperatingWorkersStore::class)]
#[CoversClass(HandlerWorkerContext::class)]
final class StaleWorkersTest extends StoreTestCase
{
    private TimeTravelerClock $clock;
    private OpenToConfigurationStore $firstStore;
    private OpenToConfigurationStore $secondStore;
    private string $tenant = 'someTenant';

    /**
     * @throws Exception
     */
    public function setUp(): void
    {
        $toRecreate = new Schema();

        $this->clock = new TimeTravelerClock();

        $this->firstStore = new OpenToConfigurationStore(DbalConnectionBuilder::build(), null, $this->clock);
        $this->firstStore->configureSchema($toRecreate);

        $this->secondStore = new OpenToConfigurationStore(DbalConnectionBuilder::build(), null, $this->clock);
        $this->secondStore->configureSchema($toRecreate);

        $this->recreateSchema($toRecreate);
    }

    /**
     * @throws \Exception
     */
    public function testStaleWorkerIsFlagged(): void
    {
        $this->firstStore->on(PointerRetrieved::class, function () {
            // Once the first worker retrieves a pointer, the time will jump and it will become stale
            $this->clock->jumpAheadInSeconds($this->firstStore->configuration->secondsToConsiderWorkerStale);
            // On sign in, the second worker will flag it
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
                $context->usingPointerInContext(function (Pointer &$pointer) {
                    $pointer = $pointer->moveTo('some-other-hash');
                });
            });
        });

        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-hash');
            });
        });

        $this->firstStore->assertOnPublishedEventOfType(StaleWorkerTickedToContinue::class, function (StaleWorkerTickedToContinue $event) {
            self::assertEquals('first-worker', $event->workerId);
        });

        $this->firstStore->assertOnPublishedEventOfType(WorkerSignedOut::class, function (WorkerSignedOut $event) {
            self::assertEquals('first-worker', $event->workerId);
        });

        $this->secondStore->assertOnPublishedEventOfType(WorkerFlaggedAsStale::class, function (WorkerFlaggedAsStale $event) {
            self::assertEquals('first-worker', $event->staleWorkerId);
        });
    }

    public function testSlowWorkerIsAbleToContinueAfterLoosingPointer(): void
    {
        $firstPointerId = -1;

        $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $secondContext) use (&$firstPointerId) {
            $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $firstContext) use ($secondContext, &$firstPointerId) {
                $firstContext->usingPointerInContext(function (Pointer &$pointerFromFirstContext) use ($secondContext, &$firstPointerId) {
                    // when the first worker locks the pointer, the time will jump to allow the second worker to re-lock the same pointer
                    $this->clock->jumpAheadInSeconds($this->firstStore->configuration->workingTimeInSeconds);

                    // the second worker will move all available pointers until it also moves the pointer from the first context
                    while ($firstPointerId !== $pointerFromFirstContext->minHash()) {
                        $secondContext->usingPointerInContext(function (Pointer &$pointerFromSecondContext) use (&$firstPointerId) {
                            $firstPointerId = $pointerFromSecondContext->minHash();
                            $pointerFromSecondContext = $pointerFromSecondContext->moveTo('some-other-hash');
                        });
                    }

                    $pointerFromFirstContext = $pointerFromFirstContext->moveTo('some-hash');
                });
            });
        });

        $this->firstStore->assertOnPublishedEventOfType(WorkerTickedToContinue::class, function (WorkerTickedToContinue $event) use ($firstPointerId) {
            self::assertEquals('first-worker', $event->workerId);
            self::assertEquals($firstPointerId, $event->lostPointerId);
        });

        $this->secondStore->assertOnPublishedEventOfType(PointerReleasedFromSlowWorker::class, function (PointerReleasedFromSlowWorker $event) use ($firstPointerId) {
            self::assertEquals($firstPointerId, $event->pointerId);
            self::assertEquals('first-worker', $event->slowWorkerId);
        });
    }

    public function testSlowWorkerLostPointerTooManyTimes(): void
    {
        $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $secondContext) {
            $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $firstContext) use ($secondContext) {
                for ($numberOfLostPointers = 0; $numberOfLostPointers < $this->firstStore->configuration->maxPointerLostBeforeStopping; ++$numberOfLostPointers) {
                    $firstContext->usingPointerInContext(function (Pointer &$pointerFromFirstContext) use ($secondContext) {
                        $this->clock->jumpAheadInSeconds($this->firstStore->configuration->workingTimeInSeconds);

                        $firstPointerId = -1;
                        while ($firstPointerId !== $pointerFromFirstContext->minHash()) {
                            $secondContext->usingPointerInContext(function (Pointer &$pointerFromSecondContext) use (&$firstPointerId) {
                                $firstPointerId = $pointerFromSecondContext->minHash();
                                $pointerFromSecondContext = $pointerFromSecondContext->moveTo('some-other-hash');
                            });
                        }

                        $pointerFromFirstContext = $pointerFromFirstContext->moveTo('some-hash');
                    });
                }
            });
        });

        $this->firstStore->assertOnPublishedEventOfType(WorkerTickedToStop::class, function (WorkerTickedToStop $event) {
            self::assertEquals('first-worker', $event->workerId);
            self::assertNotNull($event->lostPointerId);
            self::assertEquals('Worker lost the pointer 3 times.', $event->stopReason);
        });
    }

    public function testSlowWorkerBecomesStaleAndSignedOut(): void
    {
        $this->firstStore->on(PointerRetrieved::class, function () {
            // Once the first worker retrieves a pointer, the time will jump and it will become stale
            $this->clock->jumpAheadInSeconds($this->firstStore->configuration->secondsToSignOutStaleWorker);
            // On sign in, the second worker will flag it
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
                $context->usingPointerInContext(function (Pointer &$pointer) {
                    $pointer = $pointer->moveTo('some-other-hash');
                });
            });
            // On re-sign in, the second worker will sign out the stale worker
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
                $context->usingPointerInContext(function (Pointer &$pointer) {
                    $pointer = $pointer->moveTo('some-other-hash');
                });
            });
        });

        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-hash');
            });
        });

        $this->firstStore->assertOnPublishedEventOfType(WorkerTickedToStop::class, function (WorkerTickedToStop $event) {
            self::assertEquals('first-worker', $event->workerId);
            self::assertEquals('Worker is unable to continue in current state [signed_out]', $event->stopReason);
            self::assertNull($event->lostPointerId); // TODO: should an already signed out worker be allowed to persist the moved pointer????
        });

        $this->firstStore->assertOnPublishedEventOfType(AlreadySignedOutWorkerStopped::class, function (AlreadySignedOutWorkerStopped $event) {
            self::assertEquals('first-worker', $event->workerId);
        });
    }

    public function testOnceStoppedAWorkerCanNotMovePointers(): void
    {
        $this->firstStore->on(PointerRetrieved::class, function () {
            // Once the first worker retrieves a pointer, the time will jump and it will become stale
            $this->clock->jumpAheadInSeconds($this->firstStore->configuration->secondsToSignOutStaleWorker);
            // On sign in, the second worker will flag it
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
                $context->usingPointerInContext(function (Pointer &$pointer) {
                    $pointer = $pointer->moveTo('some-other-hash');
                });
            });
            // On re-sign in, the second worker will sign out the stale worker
            $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
                $context->usingPointerInContext(function (Pointer &$pointer) {
                    $pointer = $pointer->moveTo('some-other-hash');
                });
            });
            // Once signed out, the first worker is unable to continue moving pointers
        });

        self::expectException(WorkerUnableToContinue::class);

        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $ableToContinue = $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-hash');
            });

            self::assertFalse($ableToContinue);

            // Let's try to ignore the "able to continue" result and try to move another pointer
            for ($i = 0; $i < 10; ++$i) {
                $context->usingPointerInContext(function (Pointer &$pointer) use ($i) {
                    $pointer = $pointer->moveTo("some-hash-$i");
                });
            }
        });
    }
}
