<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

final class WorkerUnableToContinue extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('Worker unable to continue');
    }
}
