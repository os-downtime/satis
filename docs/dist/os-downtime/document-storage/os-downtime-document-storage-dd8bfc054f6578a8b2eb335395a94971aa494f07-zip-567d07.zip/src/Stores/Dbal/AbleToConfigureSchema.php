<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

interface AbleToConfigureSchema
{
    public function configurator(): SchemaConfigurator;
}
