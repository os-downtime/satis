<?php

declare(strict_types=1);

namespace OsDownTime\Common\Application;

use OsDownTime\Common\Domain\Event;

interface EventHandler
{
    public function reactTo(Event $event): void;
}
