<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

final readonly class RetryAwareResult
{
    private function __construct(public bool $isSuccessful, public mixed $result, public int $retryAfterSeconds)
    {
    }

    public static function retryAfter(int $retryAfterSeconds): self
    {
        return new self(false, null, $retryAfterSeconds);
    }

    public static function retryImmediately(): self
    {
        return new self(false, null, 0);
    }

    public static function success(mixed $result = null): self
    {
        return new self(true, $result, 0);
    }
}
