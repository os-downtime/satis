<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use OsDownTime\ExtendedPhp\Time\Clock;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\StoreConfiguration;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\CollectingEventDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerReleased;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerReleasedFromSlowWorker;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerRetrieved;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerSplitAndReleased;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\DbalLockablePointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\LockablePointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\DbalWorkerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\Worker;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;

final readonly class HandlerWorkerContext implements PointerContext
{
    public function __construct(
        private DbalLockablePointerStore $pointerStore,
        private DbalWorkerStore $workerStore,
        private Clock $clock,
        private CollectingEventDispatcher $dispatcher,
        private StoreConfiguration $configuration,
        private string $eventHandlerId,
        private string $workerId)
    {
    }

    /**
     * @return bool Worker is able to continue
     */
    public function usingPointerInContext(\Closure $pointerMover): bool
    {
        $pointer = $this->retrievePointer();

        $pointerMover($pointer);

        return $this->updatePointer($pointer);
    }

    private function retrievePointer(): Pointer
    {
        return Retry::untilSuccess(
            $this->configuration->timesToConsiderStuck,
            "I'm stuck retrieving a pointer",
            fn () => $this->lockAndRetrieve(),
        );
    }

    private function updatePointer(Pointer $pointer): bool
    {
        return Retry::untilSuccess(
            $this->configuration->timesToConsiderStuck,
            "I'm stuck updating a pointer",
            fn () => $this->updateAndRelease($pointer),
        );
    }

    private function lockAndRetrieve(): RetryAwareResult
    {
        $result = $this->pointerStore->grabOneToLock(
            $this->eventHandlerId,
            $this->clock->now()->modify("- {$this->configuration->workingTimeInSeconds} seconds"),
            function (?LockablePointer $pointer) {
                if (null === $pointer) {
                    return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
                }

                if (!$pointer->isFree()) {
                    $slowWorkerId = $pointer->lockedBy;
                    $pointer->release();
                    $this->dispatcher->collectEvent(new PointerReleasedFromSlowWorker($pointer->minHash, $slowWorkerId));

                    return RetryAwareResult::retryImmediately();
                }

                $pointer->lock($this->workerId, $this->clock->now());

                $this->dispatcher->collectEvent(new PointerRetrieved($pointer->minHash));

                return RetryAwareResult::success(LockedPointer::from(
                    $pointer->position,
                    $pointer->minHash,
                    $pointer->maxHash,
                    $pointer->version + 1,
                    $pointer->lockedBy,
                    $pointer->tenant,
                    $pointer->lastLockedAt,
                ));
            }
        );

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }

    private function updateAndRelease(LockedPointer $pointerToRelease): RetryAwareResult
    {
        $lostPointerId = null;

        $result = $this->pointerStore->grabByIdToRelease($this->eventHandlerId, $pointerToRelease->minHash(), function (?LockablePointer $storedPointer, ?LockablePointer &$newPointer = null) use ($pointerToRelease, &$lostPointerId) {
            if (null === $storedPointer) {
                return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
            }

            if ($storedPointer->version > $pointerToRelease->version) {
                // the stored pointer was modified while locked
                // maybe just a request to split
                // maybe we were stale and lost the pointer

                if ($pointerToRelease->maxHash() !== $storedPointer->maxHash) {
                    throw UncoveredConflict::resizedWhileLocked($pointerToRelease->minHash(), $pointerToRelease->maxHash(), $storedPointer->maxHash);
                }

                if ($storedPointer->lastLockedAt !== $pointerToRelease->lockedAt) {
                    // it is already locked (or was locked and released) by someone else
                    $lostPointerId = $pointerToRelease->minHash();

                    return null;
                }

                // ??
                // $storedPointer->version = $pointerToRelease->version;
            }

            // either no changes in the pointer while locked or the only change is a request to split

            $storedPointer->release();
            $storedPointer->position = (string) $pointerToRelease->position();

            if ($storedPointer->splitRequested()) {
                $newPointer = $storedPointer->split($this->clock->now());
                $this->dispatcher->collectEvent(new PointerSplitAndReleased($newPointer->minHash, $pointerToRelease->minHash(), $this->workerId));
            }

            $this->dispatcher->collectEvent(new PointerReleased($pointerToRelease->minHash(), $this->workerId));

            return null;
        });

        $this->dispatcher->dispatchCollectedEvents();

        if (null !== $result) {
            return $result;
        }

        return RetryAwareResult::success($this->tickWorker($lostPointerId));
    }

    private function tickWorker(?int $lostPointerId): bool
    {
        return Retry::untilSuccess(
            $this->configuration->timesToConsiderStuck,
            "I'm stuck ticking a worker",
            fn () => $this->doTickWorker($lostPointerId),
        );
    }

    /**
     * @return RetryAwareResult<bool> Worker is able to continue
     *
     * @throws \Throwable
     */
    private function doTickWorker(?int $lostPointerId): RetryAwareResult
    {
        $result = $this->workerStore->grabById($this->eventHandlerId, $this->workerId, function (?Worker $worker) use ($lostPointerId) {
            if (null === $worker) {
                return RetryAwareResult::retryAfter($this->configuration->maxTransactionDurationInSeconds);
            }

            $workerIsAbleToContinue = $worker->tick($this->clock->now(), $lostPointerId, $eventToCollect);
            $this->dispatcher->collectEvent($eventToCollect);

            return RetryAwareResult::success($workerIsAbleToContinue);
        });

        $this->dispatcher->dispatchCollectedEvents();

        return $result;
    }
}
