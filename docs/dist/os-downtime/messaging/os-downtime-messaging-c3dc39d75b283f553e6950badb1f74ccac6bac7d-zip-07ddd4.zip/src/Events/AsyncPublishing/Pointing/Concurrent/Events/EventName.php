<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

enum EventName: string
{
    case StoreInitializationFailed = 'store-initialization-failed';
    case StoreInitializationNeeded = 'store-initialization-needed';
    case StoreInitialized = 'store-initialized';
    case PointerSplitRequested = 'pointer-split-requested';
    case PointerToSplitRetrieved = 'pointer-to-split-retrieved';
    case StalePointerRetrieved = 'stale-pointer-retrieved';
    case PointerSplit = 'pointer-split';
    case PointerReleased = 'pointer-released';
    case PointerSplitAndReleased = 'pointer-split-and-released';
    case PointerReleasedFromSlowWorker = 'pointer-released-from-slow-worker';
    case StaleWorkerFlagged = 'stale-worker-flagged';
    case WorkerTickedToContinue = 'worker-ticked-to-continue';
    case StaleWorkerTickedToContinue = 'stale-worker-ticked-to-continue';
    case WorkerTickedToStop = 'worker-ticked-to-stop';
    case PointerRetrieved = 'pointer-retrieved';
    case SignedOutWorkerReplaced = 'signed-out-worker-replaced';
    case SignedOutWorkerSignedBackIn = 'signed-out-worker-signed-back-in';
    case StaleWorkerSignedBackIn = 'stale-worker-signed-back-in';
    case ReplacedWorkerSignedBackIn = 'replaced-worker-signed-back-in';
    case WorkerSignedIn = 'worker-signed-in';
    case WorkerSignedOut = 'worker-signed-out';
    case StaleWorkerSignedOut = 'stale-worker-signed-out';
    case AlreadySignedOutWorkerStopped = 'already-signed-out-worker-stopped';
}
