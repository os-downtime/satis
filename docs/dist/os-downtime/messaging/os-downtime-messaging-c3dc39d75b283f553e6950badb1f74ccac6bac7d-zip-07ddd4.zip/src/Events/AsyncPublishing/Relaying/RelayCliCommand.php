<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Command\SignalableCommandInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(name: 'odt:messaging:relay')]
final class RelayCliCommand extends Command implements SignalableCommandInterface
{
    public function __construct(private RelayWorker $worker)
    {
        parent::__construct();
    }

    public function getSubscribedSignals(): array
    {
        return [\SIGINT, \SIGTERM];
    }

    public function handleSignal(int $signal, false|int $previousExitCode = 0): int|false
    {
        $this->worker->stop();

        return false;
    }

    protected function configure(): void
    {
        $this
            ->setDescription('Relay events from the store to the endpoints')
            ->addArgument('workerId', InputArgument::REQUIRED, 'The worker ID')
            ->addArgument('eventHandlerId', InputArgument::REQUIRED, 'The event handler ID to relay events to')
            ->addArgument('maxEventsToRelay', InputArgument::OPTIONAL, 'The maximum number of events to relay', 0)
            ->addArgument('batchSize', InputArgument::OPTIONAL, 'The number of events to relay in a batch', 10)
            ->addArgument('sleepSeconds', InputArgument::OPTIONAL, 'Seconds to sleep on empty queue', 5)
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->writeln('Relaying...');

        $this->worker->start(new WorkerOptions(
            (int) $input->getArgument('batchSize'),
            $input->getArgument('eventHandlerId'),
            (int) $input->getArgument('maxEventsToRelay'),
            (int) $input->getArgument('sleepSeconds'),
            $input->getArgument('workerId'),
        ));

        return Command::SUCCESS;
    }
}
