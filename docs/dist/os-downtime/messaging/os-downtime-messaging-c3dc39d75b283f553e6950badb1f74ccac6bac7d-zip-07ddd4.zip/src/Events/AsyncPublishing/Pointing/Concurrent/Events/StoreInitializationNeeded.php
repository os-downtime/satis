<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class StoreInitializationNeeded implements StoreEvent
{
    public function __construct(public string $eventHandlerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::StoreInitializationNeeded;
    }
}
