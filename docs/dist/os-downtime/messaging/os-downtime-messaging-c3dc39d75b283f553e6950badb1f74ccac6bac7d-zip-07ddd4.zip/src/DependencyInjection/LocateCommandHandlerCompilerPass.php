<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\DependencyInjection;

use OsDownTime\Messaging\Commands\CommandHandler;
use OsDownTime\Messaging\Commands\ServiceLocatorCommandBus;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\Compiler\ServiceLocatorTagPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

final readonly class LocateCommandHandlerCompilerPass implements CompilerPassInterface
{
    public const string COMMAND_HANDLER_TAG = 'odt.messaging.command_handler';

    public function process(ContainerBuilder $container): void
    {
        $commandBusDefinition = $container->findDefinition(ServiceLocatorCommandBus::class);

        $taggedCommandHandlers = $container->findTaggedServiceIds(self::COMMAND_HANDLER_TAG);

        $indexedCommandsWithHandlers = [];

        foreach ($taggedCommandHandlers as $id => $tags) {
            $handlerDefinition = $container->findDefinition($id);
            /** @var CommandHandler $handlerClass */
            $handlerClass = $handlerDefinition->getClass();
            $handledCommands = $handlerClass::handledCommands();
            foreach ($handledCommands as $command) {
                $indexedCommandsWithHandlers[$command] = new Reference($id);
            }
        }

        $commandBusDefinition->addArgument(ServiceLocatorTagPass::register($container, $indexedCommandsWithHandlers));
    }
}
