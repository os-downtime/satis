<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

final readonly class BatchResult
{
    private function __construct(public bool $canContinue, public int $eventsRelayed)
    {
    }

    public static function continue(int $eventsRelayed): self
    {
        return new self(true, $eventsRelayed);
    }

    public static function stop(int $eventsRelayed): self
    {
        return new self(false, $eventsRelayed);
    }
}
