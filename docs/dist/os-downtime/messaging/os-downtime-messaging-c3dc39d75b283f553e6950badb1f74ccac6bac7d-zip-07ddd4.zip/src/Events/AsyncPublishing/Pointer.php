<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing;

interface Pointer
{
    public function position(): Position;

    public function range(): HashRange;

    public function eventHandlerId(): string;

    public function minHash(): int;

    public function maxHash(): int;

    public function moveTo(string $newPosition): Pointer;
}
