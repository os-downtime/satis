<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events;

use OsDownTime\Common\Domain\Event;

trait EventHandlerTrait
{
    public function reactTo(Event $event): void
    {
        $eventIndex = array_search($event::class, self::handledEvents());
        $methodName = sprintf('reactTo%s', $eventIndex);
        $this->{$methodName}($event);
    }

    abstract public static function handledEvents(): array;
}
