<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing;

use OsDownTime\Common\Domain\Event;
use OsDownTime\Common\Domain\EventBus;
use OsDownTime\Messaging\Events\AsyncPublishing\Recording\EventRecorder;

/**
 * Publishing an event asynchronously will be a two steps process:
 * 1- Recording the event to the DB transactionally with the state changing operation
 * 2- Relaying (retrieving from Db and delivering) the event to the handler.
 */
final readonly class AsyncEventBus implements EventBus
{
    public function __construct(private EventRecorder $recorder)
    {
    }

    public function publish(Event ...$events): void
    {
        $this->recorder->record(...$events);
    }
}
