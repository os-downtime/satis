<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

use Symfony\Component\EventDispatcher\EventDispatcher;

final class StoreEventAwareDispatcher extends EventDispatcher
{
    public function dispatch(object $event, ?string $eventName = null): object
    {
        if ($event instanceof StoreEvent) {
            return parent::dispatch($event, $event::eventName()->value);
        }

        return parent::dispatch($event, $eventName);
    }
}
