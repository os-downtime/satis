<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Serialization;

/**
 *  Marker interface to signal objects that can be (de)serialized by the
 *  Symfony\Component\Serializer\SerializerInterface configured in the application DIC.
 */
interface ExternallySerializable
{
}
