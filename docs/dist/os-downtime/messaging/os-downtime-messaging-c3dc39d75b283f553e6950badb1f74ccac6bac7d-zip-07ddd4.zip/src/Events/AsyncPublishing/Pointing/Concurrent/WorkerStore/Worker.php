<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\AlreadySignedOutWorkerStopped;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\ReplacedWorkerSignedBackIn;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\SignedOutWorkerReplaced;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\SignedOutWorkerSignedBackIn;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StaleWorkerSignedBackIn;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StaleWorkerSignedOut;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StaleWorkerTickedToContinue;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerFlaggedAsStale;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerSignedIn;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerSignedOut;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerTickedToContinue;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerTickedToStop;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\UncoveredConflict;

final class Worker
{
    public function __construct(
        public string $id,
        public string $tenant,
        public WorkerState $state,
        public \DateTimeImmutable $lastTickAt,
        public int $timesPointerLost,
        public int $version,
        public int $maxTimesPointerLost,
    ) {
    }

    public static function signIn(string $id, string $tenant, \DateTimeImmutable $now, int $maxTimesPointerLost, ?StoreEvent &$event = null): Worker
    {
        $event = new WorkerSignedIn($id);

        return new self($id, $tenant, WorkerState::ACTIVE, $now, 0, 1, $maxTimesPointerLost);
    }

    public function isSignedOut(): bool
    {
        return WorkerState::SIGNED_OUT === $this->state;
    }

    /**
     * @return bool Is able to continue
     */
    public function tick(\DateTimeImmutable $now, ?int $lostPointerId = null, ?StoreEvent &$event = null): bool
    {
        $this->lastTickAt = $now;

        if (null !== $lostPointerId) {
            ++$this->timesPointerLost;
        } else {
            $this->timesPointerLost = 0;
        }

        if ($this->timesPointerLost >= $this->maxTimesPointerLost) {
            $event = new WorkerTickedToStop($this->id, "Worker lost the pointer $this->timesPointerLost times.", $lostPointerId);

            return false;
        }

        if ($this->isActive()) {
            $event = new WorkerTickedToContinue($this->id, $lostPointerId);

            return true;
        }

        if ($this->isStale()) {
            $event = new StaleWorkerTickedToContinue($this->id, $lostPointerId);
            $this->state = WorkerState::ACTIVE;

            return true;
        }

        $event = new WorkerTickedToStop($this->id, "Worker is unable to continue in current state [{$this->state->value}]", $lostPointerId);

        return false;
    }

    /**
     * @return bool Needs pointer split after sign in
     */
    public function signBackIn(\DateTimeImmutable $signInTime, ?StoreEvent &$event = null): bool
    {
        $needsPointerSplit = false;

        if ($this->isSignedOut()) {
            $event = new SignedOutWorkerSignedBackIn($this->id);
        }

        if ($this->isStale()) {
            // TODO: Validate that this should not be possible
            $event = new StaleWorkerSignedBackIn($this->id);
        }

        if ($this->isReplaced()) {
            $event = new ReplacedWorkerSignedBackIn($this->id);
            $needsPointerSplit = true;
        }

        if ($this->isActive()) {
            throw new \RuntimeException("Worker '$this->id' is already active");
        }

        $this->state = WorkerState::ACTIVE;
        $this->lastTickAt = $signInTime;

        return $needsPointerSplit;
    }

    public function isActive(): bool
    {
        return WorkerState::ACTIVE === $this->state;
    }

    public function flagStale(?StoreEvent &$event = null): void
    {
        if (!$this->isActive()) {
            throw UncoveredConflict::inactiveWorkerFlaggedStale($this->id);
        }

        $this->state = WorkerState::STALE;
        $event = new WorkerFlaggedAsStale($this->id);
    }

    public function isStale(): bool
    {
        return WorkerState::STALE === $this->state;
    }

    public function replaceSignedOut(string $replacingWorkerId, ?StoreEvent &$event = null): void
    {
        if (!$this->isSignedOut()) {
            throw UncoveredConflict::signedInWorkerReplaced($this->id);
        }

        $this->state = WorkerState::REPLACED;
        $event = new SignedOutWorkerReplaced($this->id, $replacingWorkerId);
    }

    public function signOut(?StoreEvent &$event = null): void
    {
        $signedOut = false;

        if ($this->isActive()) {
            $event = new WorkerSignedOut($this->id);
            $signedOut = true;
        }

        if ($this->isStale()) {
            $event = new StaleWorkerSignedOut($this->id);
            $signedOut = true;
        }

        if ($this->isSignedOut()) {
            $event = new AlreadySignedOutWorkerStopped($this->id);
            $signedOut = true;
        }

        if (!$signedOut) {
            throw UncoveredConflict::unexpectedStateAtSignOut($this->id, $this->state->value);
        }

        $this->state = WorkerState::SIGNED_OUT;
    }

    public function isReplaced(): bool
    {
        return WorkerState::REPLACED === $this->state;
    }
}
