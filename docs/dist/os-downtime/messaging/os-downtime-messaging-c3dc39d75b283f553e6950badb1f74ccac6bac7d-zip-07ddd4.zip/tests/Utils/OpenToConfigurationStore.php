<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Schema\Schema;
use OsDownTime\ExtendedPhp\Time\Clock;
use OsDownTime\ExtendedPhp\Time\DefaultClock;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\DefaultConfigurationLoader;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\StoreConfiguration;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\ContextFactory;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\CollectingEventDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEventAwareDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\DbalLockablePointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers\SubscriberToAllEvents;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\DbalWorkerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerStore;
use Psr\EventDispatcher\EventDispatcherInterface;

final class OpenToConfigurationStore implements PointerStore
{
    private DbalLockablePointerStore $pointerStore;
    private DbalWorkerStore $workerStore;
    private CollectingEventDispatcher $dispatcher;
    private EventDispatcherInterface $innerDispatcher;
    private ?CooperatingWorkersStore $statefulStore;

    private EventCollector $eventCollector;

    public function __construct(public Connection $connection, public ?StoreConfiguration $configuration = null, public ?Clock $clock = null)
    {
        if (null === $this->configuration) {
            $this->configuration = StoreConfiguration::default();
        }

        if (null === $this->clock) {
            $this->clock = new DefaultClock();
        }

        $this->innerDispatcher = new StoreEventAwareDispatcher();

        $this->dispatcher = new CollectingEventDispatcher($this->innerDispatcher);

        $this->pointerStore = new DbalLockablePointerStore($connection);

        $this->workerStore = new DbalWorkerStore($this->connection);

        $this->eventCollector = new EventCollector();

        $this->innerDispatcher->addSubscriber(new SubscriberToAllEvents($this->eventCollector));

        $this->statefulStore = null;
    }

    public function changeConfiguration(StoreConfiguration $configChange): void
    {
        $this->configuration = $configChange;
    }

    public function build(): void
    {
        $defaultLoader = new DefaultConfigurationLoader($this->configuration);

        $this->statefulStore = new CooperatingWorkersStore(
            $this->pointerStore,
            $this->workerStore,
            $this->clock,
            $this->dispatcher,
            new ContextFactory(
                $this->pointerStore,
                $this->workerStore,
                $this->clock,
                $this->dispatcher,
                $defaultLoader
            ),
            $defaultLoader
        );
    }

    public function configureSchema(Schema $toBeConfigured): void
    {
        $this->pointerStore->configureSchema($toBeConfigured, fn () => true);
        $this->workerStore->configureSchema($toBeConfigured, fn () => true);
    }

    public function on(string $eventClass, callable $listener): void
    {
        $this->innerDispatcher->addListener($eventClass::eventName()->value, $listener);
    }

    /**
     * @return string[]
     */
    public function typesOfPublishedEvents(): array
    {
        return array_map(fn (StoreEvent $event) => $event::class, $this->eventCollector->events);
    }

    public function assertOnPublishedEventOfType(string $eventType, callable $assert): void
    {
        $publishedEvents = array_values(array_filter($this->eventCollector->events, fn (StoreEvent $event) => $event::class === $eventType));

        if (1 !== count($publishedEvents)) {
            throw new \Exception('No event of type '.$eventType.' was published');
        }

        $assert($publishedEvents[0]);
    }

    public function clearPublishedEvents(): void
    {
        $this->eventCollector->events = [];
    }

    public function usingContextFor(string $workerId, string $eventHandlerId, \Closure $contextHandler): void
    {
        if (null === $this->statefulStore) {
            $this->build();
        }

        $this->statefulStore->usingContextFor($workerId, $eventHandlerId, $contextHandler);
    }
}
