<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;

final class StopAwareContext implements PointerContext
{
    public function __construct(private readonly PointerContext $wrappedContext, private bool $continue = true)
    {
    }

    public function usingPointerInContext(\Closure $pointerMover): bool
    {
        if (!$this->continue) {
            throw new WorkerUnableToContinue();
        }

        $this->continue = $this->wrappedContext->usingPointerInContext($pointerMover);

        return $this->continue;
    }
}
