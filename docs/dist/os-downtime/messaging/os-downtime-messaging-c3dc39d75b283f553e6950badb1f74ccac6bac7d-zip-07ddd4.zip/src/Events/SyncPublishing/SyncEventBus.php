<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\SyncPublishing;

use OsDownTime\Common\Domain\Event;
use OsDownTime\Common\Domain\EventBus;

final readonly class SyncEventBus implements EventBus
{
    public function __construct(private EventDeliverer $deliverer)
    {
    }

    public function publish(Event ...$events): void
    {
        $this->deliverer->deliver(null, ...$events);
    }
}
