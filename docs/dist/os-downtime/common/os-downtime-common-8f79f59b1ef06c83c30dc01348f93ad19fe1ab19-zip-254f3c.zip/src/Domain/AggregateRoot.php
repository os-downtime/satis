<?php

declare(strict_types=1);

namespace OsDownTime\Common\Domain;

use OsDownTime\ExtendedPhp\Normalization\NormalizableWithVersionBySome;

abstract class AggregateRoot implements NormalizableWithVersionBySome
{
    protected array $events = [];

    protected function recordThat(Event $event): void
    {
        $this->events[] = $event;
    }

    public function popRecordedEvents(): array
    {
        $events = $this->events;
        $this->events = [];

        return $events;
    }
}
