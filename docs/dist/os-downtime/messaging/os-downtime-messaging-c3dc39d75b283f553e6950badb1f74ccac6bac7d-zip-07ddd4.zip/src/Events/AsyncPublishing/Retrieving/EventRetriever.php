<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Retrieving;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;

interface EventRetriever
{
    public function retrieveAndDeliver(Pointer $from, int $numberOfEventsToDeliver): RetrieveResult;
}
