<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;
use Psr\Log\LoggerInterface;
use Symfony\Component\Serializer\SerializerInterface;

final readonly class EventLogger implements StoreEventHandler
{
    public function __construct(private LoggerInterface $logger, private SerializerInterface $serializer)
    {
    }

    public function handle(StoreEvent $event): void
    {
        $this->logger->debug($event->eventName()->value, [json_decode($this->serializer->serialize($event, 'json'), true)]);
    }
}
