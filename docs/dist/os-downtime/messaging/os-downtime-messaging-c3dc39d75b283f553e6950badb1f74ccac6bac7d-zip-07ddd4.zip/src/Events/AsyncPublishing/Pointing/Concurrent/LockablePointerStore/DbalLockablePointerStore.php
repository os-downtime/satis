<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Doctrine\DBAL\Query\ForUpdate\ConflictResolutionMode;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use OsDownTime\DocumentStorage\Stores\Dbal\AbleToConfigureSchema;
use OsDownTime\DocumentStorage\Stores\Dbal\SchemaConfigurator;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\RetryAwareResult;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\UncoveredConflict;

/**
 * We store Pointers: "references" to a position in an ordered list of Partitionable Items.
 * The pointer's minHash and maxHash define a "partition" in the list,
 * basically a subset of the items from the original list (with hashes within that range).
 * The items in this partition have are ordered.
 * A pointer uniquely identifies a position in that partition.
 *
 * Pointers in this store (for a single tenant) do not overlap and cover the full hash global range:
 *  - no two pointers define overlapping ranges
 *  - there is no hash value within the "hash global range" not "matching" with a pointer's range
 *
 * The store is logically divided in tenants.
 */
final readonly class DbalLockablePointerStore implements SchemaConfigurator, AbleToConfigureSchema
{
    private const string LOCKABLE_POINTERS_TABLE_NAME = 'lockable_pointers';

    public function __construct(private Connection $connection)
    {
    }

    public function configurator(): SchemaConfigurator
    {
        return $this;
    }

    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void
    {
        if ($schema->hasTable(self::LOCKABLE_POINTERS_TABLE_NAME)) {
            return;
        }

        if (!$isSameDatabase($this->connection->executeStatement(...))) {
            return;
        }

        $table = $schema->createTable(self::LOCKABLE_POINTERS_TABLE_NAME);

        $table->addColumn('min_hash', Types::BIGINT);
        $table->addColumn('max_hash', Types::BIGINT);
        $table->addColumn('tenant', Types::STRING);
        $table->addColumn('request', Types::STRING, ['default' => null, 'notnull' => false]);
        $table->addColumn('locked_by', Types::STRING, ['default' => null, 'notnull' => false]);
        $table->addColumn('position', Types::TEXT);
        $table->addColumn('size', Types::BIGINT);
        $table->addColumn('last_released_at', Types::DATETIMETZ_IMMUTABLE, ['default' => null, 'notnull' => false]);
        $table->addColumn('last_locked_at', Types::DATETIMETZ_IMMUTABLE, ['default' => null, 'notnull' => false]);
        $table->addColumn('last_split_at', Types::DATETIMETZ_IMMUTABLE, ['default' => null, 'notnull' => false]);
        $table->addColumn('version', Types::BIGINT, ['default' => 1]);

        $table->setPrimaryKey(['min_hash', 'tenant']);
    }

    public function hasPointersFor(string $tenant): bool
    {
        return 1 === $this->connection->createQueryBuilder()
                ->select('1')
                ->from(self::LOCKABLE_POINTERS_TABLE_NAME, 'i')
                ->where('i.tenant = :sn')
                ->setParameter('sn', $tenant)
                ->executeQuery()
                ->fetchOne();
    }

    public function insert(LockablePointer ...$pointers): bool
    {
        $params = $types = [];
        foreach ($pointers as $pointer) {
            $params[] = $pointer->minHash;
            $params[] = $pointer->maxHash;
            $params[] = $pointer->tenant;
            $params[] = $pointer->request;
            $params[] = $pointer->lockedBy;
            $params[] = $pointer->position;
            $params[] = $pointer->size;
            $params[] = $pointer->lastReleasedAt;
            $params[] = $pointer->lastLockedAt;
            $params[] = $pointer->lastSplitAt;
            $params[] = $pointer->version;

            array_push(
                $types,
                Types::BIGINT,
                Types::BIGINT,
                Types::STRING,
                Types::STRING,
                Types::STRING,
                Types::TEXT,
                Types::BIGINT,
                Types::DATETIMETZ_IMMUTABLE,
                Types::DATETIMETZ_IMMUTABLE,
                Types::DATETIMETZ_IMMUTABLE,
                Types::INTEGER,
            );
        }

        try {
            $affectedRows = $this->connection->executeStatement(
                sprintf(
                    'INSERT INTO %s (min_hash, max_hash, tenant, request, locked_by, position, size, last_released_at, last_locked_at, last_split_at, version) VALUES %s',
                    self::LOCKABLE_POINTERS_TABLE_NAME,
                    implode(', ', array_map(static fn (LockablePointer $partition): string => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', $pointers)),
                ),
                $params,
                $types,
            );
        } catch (UniqueConstraintViolationException) {
            return false;
        }

        return $affectedRows === count($pointers);
    }

    public function update(LockablePointer $pointer, bool $commitTransaction = false): bool
    {
        $numberOfUpdatedRows = $this->connection->createQueryBuilder()
            ->update(self::LOCKABLE_POINTERS_TABLE_NAME)
            ->set('max_hash', ':maxh')
            ->setParameter('maxh', $pointer->maxHash)
            ->set('request', ':rq')
            ->setParameter('rq', $pointer->request)
            ->set('locked_by', ':aby')
            ->setParameter('aby', $pointer->lockedBy)
            ->set('position', ':pl')
            ->setParameter('pl', $pointer->position)
            ->set('last_locked_at', ':aat')
            ->setParameter('aat', $pointer->lastLockedAt, Types::DATETIMETZ_IMMUTABLE)
            ->set('last_split_at', ':sat')
            ->setParameter('sat', $pointer->lastSplitAt, Types::DATETIMETZ_IMMUTABLE)
            ->set('version', 'version + 1')
            ->where('min_hash = :minh')
            ->setParameter('minh', $pointer->minHash)
            ->andWhere('tenant = :sn')
            ->setParameter('sn', $pointer->tenant)
            ->andWhere('version = :cVl')
            ->setParameter('cVl', $pointer->version)
            ->executeStatement();

        if ($commitTransaction) {
            $this->connection->commit();
        }

        if (1 === $numberOfUpdatedRows) {
            ++$pointer->version;

            return true;
        }

        return false;
    }

    public function grabOneToLock(string $tenant, \DateTimeImmutable $lastLockedBefore, \Closure $grabber): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('p.*')
            ->from(self::LOCKABLE_POINTERS_TABLE_NAME, 'p')
            ->where('p.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('p.locked_by IS NULL OR p.last_locked_at < :ab')// avoid grabbing one recently locked (within the working time)
            ->setParameter('sn', $tenant)
            ->setParameter('ab', $lastLockedBefore, Types::DATETIMETZ_IMMUTABLE)
            ->orderBy('p.last_locked_at', 'ASC NULLS FIRST')
            ->addOrderBy('p.version', 'ASC')
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $pointer = null;

        if (count($rows) > 0) {
            $pointer = $this->hydratePointer($rows[0]);
        }

        try {
            $result = $grabber($pointer);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $updateSuccess = null;

        if (null !== $pointer) {
            $updateSuccess = $this->update($pointer);
        }

        if (false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('locking pointer');
        }

        $this->connection->commit();

        return $result;
    }

    /**
     * @throws \DateMalformedStringException
     */
    private function hydratePointer(array $row): LockablePointer
    {
        return new LockablePointer(
            minHash: (int) $row['min_hash'],
            maxHash: (int) $row['max_hash'],
            tenant: $row['tenant'],
            request: $row['request'],
            position: $row['position'],
            size: (int) $row['size'],
            lockedBy: $row['locked_by'],
            lastReleasedAt: null !== $row['last_released_at'] ? new \DateTimeImmutable($row['last_released_at']) : null,
            lastLockedAt: null !== $row['last_locked_at'] ? new \DateTimeImmutable($row['last_locked_at']) : null,
            lastSplitAt: null !== $row['last_split_at'] ? new \DateTimeImmutable($row['last_split_at']) : null,
            version: (int) $row['version'],
        );
    }

    public function grabByIdToRelease(string $tenant, int $minHash, \Closure $grabber): ?RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('p.*')
            ->from(self::LOCKABLE_POINTERS_TABLE_NAME, 'p')
            ->where('p.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->andWhere('p.min_hash = :smh')
            ->setParameter('sn', $tenant)
            ->setParameter('smh', $minHash)
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $storedPointer = null;

        if (count($rows) > 0) {
            $storedPointer = $this->hydratePointer($rows[0]);
        }

        $newPointer = null;

        try {
            $innerResult = $grabber($storedPointer, $newPointer);
        } catch (\Throwable $e) {
            $this->connection->rollBack();
            throw $e;
        }

        $insertSuccess = null;
        $updateSuccess = null;

        if (null !== $newPointer) {
            $insertSuccess = $this->insert($newPointer);
        }

        if (null !== $storedPointer) {
            $updateSuccess = $this->update($storedPointer);
        }

        if (false === $insertSuccess || false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('release pointer');
        }

        $this->connection->commit();

        return $innerResult;
    }

    public function grabBiggestNotSplitForLonger(string $tenant, \Closure $splitter): RetryAwareResult
    {
        $this->connection->beginTransaction();

        $rows = $this->connection->createQueryBuilder()
            ->select('p.*')
            ->from(self::LOCKABLE_POINTERS_TABLE_NAME, 'p')
            ->where('p.tenant = :sn')
            ->forUpdate(ConflictResolutionMode::SKIP_LOCKED)
            ->setParameter('sn', $tenant)
            ->orderBy('p.size', 'DESC') // grab the biggest available pointer
            ->addOrderBy('p.last_split_at', 'ASC NULLS FIRST') // the one not split for longer, if more than one
            ->setMaxResults(1)
            ->executeQuery()
            ->fetchAllAssociative();

        $pointer = null;

        if (count($rows) > 0) {
            $pointer = $this->hydratePointer($rows[0]);
        }

        $newPointers = [];

        $innerResult = $splitter($pointer, $newPointers);

        $insertSuccess = null;
        $updateSuccess = null;

        if (null !== $pointer) {
            $updateSuccess = $this->update($pointer);
        }

        if (count($newPointers) > 0) {
            $insertSuccess = $this->insert(...$newPointers);
        }

        if (false === $insertSuccess || false === $updateSuccess) {
            $this->connection->rollBack();

            throw UncoveredConflict::grabFailedFor('biggest pointer not split for longer');
        }

        $this->connection->commit();

        return $innerResult;
    }
}
