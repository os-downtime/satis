<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Events;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Schema;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\HandlerWorkerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Tests\Utils\DbalConnectionBuilder;
use OsDownTime\Messaging\Tests\Utils\OpenToConfigurationStore;
use OsDownTime\Messaging\Tests\Utils\PartitionableCollection\CollectionBuilder;
use OsDownTime\Messaging\Tests\Utils\StoreTestCase;
use PHPUnit\Framework\Attributes\CoversClass;

#[CoversClass(CooperatingWorkersStore::class)]
#[CoversClass(HandlerWorkerContext::class)]
final class SingleWorkerTest extends StoreTestCase
{
    private OpenToConfigurationStore $target;
    private string $tenant = 'someTenant';
    private string $workerId = 'someWorkerId';

    /**
     * @throws Exception
     */
    protected function setUp(): void
    {
        $schema = new Schema();

        $this->target = new OpenToConfigurationStore(DbalConnectionBuilder::build());

        $this->target->configureSchema($schema);

        $this->recreateSchema($schema);
    }

    public function testItRetrievesAPointer(): void
    {
        $this->target->usingContextFor($this->workerId, $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (?Pointer $pointer) {
                self::assertNotNull($pointer);

                return 1;
            });
        });
    }

    public function testPartitionsAreSuccessfullyIterated(): void
    {
        $collection = CollectionBuilder::populateWith(10, 3, 10);

        $worstCaseScenario = $collection->totalItems() * $this->target->configuration->initialPointersCount;

        $this->target->usingContextFor($this->workerId, $this->tenant, function (PointerContext $context) use ($collection, $worstCaseScenario) {
            while ($collection->handledPointersCount() < $worstCaseScenario) {
                $context->usingPointerInContext(function (?Pointer &$pointer) use ($collection) {
                    $pointer = $collection->handle($pointer);

                    return 1;
                });
            }
        });

        self::assertTrue($collection->allItemsWereHandled($message), $message);
        self::assertTrue($collection->allItemsWereHandledOnlyOnce($message), $message);
        self::assertTrue($collection->allItemsWereHandledInOrder($message), $message);
    }
}
