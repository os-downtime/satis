<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing;

final readonly class HashRange
{
    private function __construct(public int $minHash, public int $maxHash)
    {
    }

    public static function create(int $minHash, int $maxHash): self
    {
        // TODO: validate
        return new self($minHash, $maxHash);
    }

    public static function max(): self
    {
        return new self(0, PHP_INT_MAX);
    }
}
