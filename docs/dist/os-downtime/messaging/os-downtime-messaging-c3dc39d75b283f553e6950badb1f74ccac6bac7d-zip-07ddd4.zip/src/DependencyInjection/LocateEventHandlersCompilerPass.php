<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\DependencyInjection;

use OsDownTime\Messaging\Events\EventHandler;
use OsDownTime\Messaging\Events\SyncPublishing\ServiceLocatorEventDeliverer;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\Compiler\ServiceLocatorTagPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

final readonly class LocateEventHandlersCompilerPass implements CompilerPassInterface
{
    public const string EVENT_HANDLER_TAG = 'odt.messaging.event_handler';

    public function process(ContainerBuilder $container): void
    {
        $eventBusDefinition = $container->findDefinition(ServiceLocatorEventDeliverer::class);

        $taggedEventHandlers = $container->findTaggedServiceIds(self::EVENT_HANDLER_TAG);

        $handlersPerEvent = [];
        $indexedHandlers = [];

        foreach ($taggedEventHandlers as $id => $tags) {
            $handlerDefinition = $container->findDefinition($id);
            $handlerClass = $handlerDefinition->getClass();

            $indexedHandlers[$handlerClass] = new Reference($id);

            /** @var EventHandler $handlerClass */
            $handledEvents = $handlerClass::handledEvents();
            foreach ($handledEvents as $event) {
                if (!array_key_exists($event, $handlersPerEvent)) {
                    $handlersPerEvent[$event] = [];
                }
                $handlersPerEvent[$event][] = $handlerClass;
            }
        }

        $eventBusDefinition->setArgument('$locator', ServiceLocatorTagPass::register($container, $indexedHandlers));
        $eventBusDefinition->setArgument('$handlersPerEvent', $handlersPerEvent);
    }
}
