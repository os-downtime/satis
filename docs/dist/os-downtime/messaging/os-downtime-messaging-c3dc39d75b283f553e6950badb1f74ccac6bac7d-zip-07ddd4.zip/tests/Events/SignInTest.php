<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Events;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Schema\Schema;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\StoreConfiguration;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\PointerSplit;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\SignedOutWorkerReplaced;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\SignedOutWorkerSignedBackIn;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\WorkerSignedOut;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\HandlerWorkerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\Events\PointerToSplitGrabbed;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Tests\Utils\DbalConnectionBuilder;
use OsDownTime\Messaging\Tests\Utils\OpenToConfigurationStore;
use OsDownTime\Messaging\Tests\Utils\StoreTestCase;
use PHPUnit\Framework\Attributes\CoversClass;

#[CoversClass(CooperatingWorkersStore::class)]
#[CoversClass(HandlerWorkerContext::class)]
final class SignInTest extends StoreTestCase
{
    private OpenToConfigurationStore $firstStore;
    private OpenToConfigurationStore $secondStore;
    private string $tenant = 'someTenant';

    /**
     * @throws Exception
     */
    public function setUp(): void
    {
        $toRecreate = new Schema();

        $this->firstStore = new OpenToConfigurationStore(DbalConnectionBuilder::build());
        $this->firstStore->configureSchema($toRecreate);

        $this->secondStore = new OpenToConfigurationStore(DbalConnectionBuilder::build());

        $this->recreateSchema($toRecreate);
    }

    public function testTwoWorkersCanNotRetrieveSamePointerToSplit(): void
    {
        $this->firstStore->on(PointerToSplitGrabbed::class, function (PointerToSplitGrabbed $firstEvent) {
            $this->secondStore->on(PointerToSplitGrabbed::class, function (PointerToSplitGrabbed $secondEvent) use ($firstEvent) {
                $this->assertNotEquals($firstEvent->minHash, $secondEvent->minHash);
            });

            $this->secondStore->usingContextFor('worker2', $this->tenant, function (PointerContext $context) {});
        });

        $this->firstStore->usingContextFor('worker1', $this->tenant, function (PointerContext $context) {});
    }

    /**
     * @throws Exception
     */
    public function testNoPointersAvailableToSplit(): void
    {
        $configuration = new StoreConfiguration(2, 120, 2, 0, 2, 3);
        $this->firstStore->changeConfiguration($configuration);
        $this->secondStore->changeConfiguration($configuration);
        $thirdStore = new OpenToConfigurationStore(DbalConnectionBuilder::build(), $configuration);

        $this->firstStore->on(PointerToSplitGrabbed::class, function () use ($thirdStore) {
            $this->secondStore->on(PointerToSplitGrabbed::class, function () use ($thirdStore) {
                try {
                    $thirdStore->usingContextFor('worker3', $this->tenant, function (PointerContext $context) {});
                } catch (\RuntimeException $e) {
                    self::assertEquals("I'm stuck splitting a pointer", $e->getMessage());
                }
            });

            $this->secondStore->usingContextFor('worker2', $this->tenant, function (PointerContext $context) {});
        });

        $this->firstStore->usingContextFor('worker1', $this->tenant, function (PointerContext $context) {});
    }

    /**
     * @throws \Exception
     */
    public function testSigningWorkerReplacesSignedOutWorker(): void
    {
        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-hash');
            });
        });

        $this->secondStore->usingContextFor('second-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-other-hash');
            });
        });

        $this->secondStore->assertOnPublishedEventOfType(SignedOutWorkerReplaced::class, function (SignedOutWorkerReplaced $event) {
            self::assertEquals('first-worker', $event->signedOutWorkerId);
            self::assertEquals('second-worker', $event->replacingWorkerId);
        });
    }

    /**
     * @throws \Exception
     */
    public function testSignedOutWorkerSignsBackIn(): void
    {
        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-hash');
            });
        });

        self::assertContains(PointerSplit::class, $this->firstStore->typesOfPublishedEvents());

        $this->firstStore->assertOnPublishedEventOfType(WorkerSignedOut::class, function (WorkerSignedOut $event) {
            self::assertEquals('first-worker', $event->workerId);
        });

        $this->firstStore->clearPublishedEvents();

        $this->firstStore->usingContextFor('first-worker', $this->tenant, function (PointerContext $context) {
            $context->usingPointerInContext(function (Pointer &$pointer) {
                $pointer = $pointer->moveTo('some-other-hash');
            });
        });

        self::assertNotContains(PointerSplit::class, $this->firstStore->typesOfPublishedEvents());

        $this->firstStore->assertOnPublishedEventOfType(SignedOutWorkerSignedBackIn::class, function (SignedOutWorkerSignedBackIn $event) {
            self::assertEquals('first-worker', $event->workerId);
        });
    }
}
