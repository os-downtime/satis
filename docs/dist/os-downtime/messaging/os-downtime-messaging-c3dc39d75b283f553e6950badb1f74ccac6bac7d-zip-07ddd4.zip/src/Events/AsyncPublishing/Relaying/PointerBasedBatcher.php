<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;
use OsDownTime\Messaging\Events\AsyncPublishing\Retrieving\EventRetriever;

final readonly class PointerBasedBatcher implements RelayBatcher
{
    public function __construct(private PointerContext $pointerContext, private EventRetriever $eventDeliverer)
    {
    }

    public function nextBatch(int $batchSize): BatchResult
    {
        $total = 0;

        $continue = $this->pointerContext->usingPointerInContext(function (Pointer &$pointer) use ($batchSize, &$total) {
            $retrieveResult = $this->eventDeliverer->retrieveAndDeliver($pointer, $batchSize);

            if ($retrieveResult->totalDelivered > 0) {
                $pointer = $pointer->moveTo($retrieveResult->lastUniqueEventIdDelivered);
            }

            $total = $retrieveResult->totalDelivered;
        });

        if ($continue) {
            return BatchResult::continue($total);
        }

        return BatchResult::stop($total);
    }
}
