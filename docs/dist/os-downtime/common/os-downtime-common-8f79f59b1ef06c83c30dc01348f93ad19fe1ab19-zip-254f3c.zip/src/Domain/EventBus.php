<?php

declare(strict_types=1);

namespace OsDownTime\Common\Domain;

interface EventBus
{
    public function publish(Event ...$events): void;
}
