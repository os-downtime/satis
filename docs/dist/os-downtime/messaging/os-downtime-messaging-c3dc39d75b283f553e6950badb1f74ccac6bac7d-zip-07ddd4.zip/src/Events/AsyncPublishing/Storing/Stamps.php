<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Storing;

final class Stamps
{
    private array $index;

    public function __construct(Stamp ...$stamps)
    {
        $indexedStamps = [];

        foreach ($stamps as $stamp) {
            if (!array_key_exists($stamp->name, $indexedStamps)) {
                $indexedStamps[$stamp->name] = [];
            }
            $indexedStamps[$stamp->name][] = $stamp->value;
        }

        $this->index = $indexedStamps;
    }

    public function stampValue(string $name): string
    {
        return $this->index[$name][count($this->index[$name]) - 1];
    }

    /**
     * @return Stamp[]
     */
    public function all(): iterable
    {
        foreach ($this->index as $name => $collectionOfValues) {
            foreach ($collectionOfValues as $value) {
                yield new Stamp($name, $value);
            }
        }
    }
}
