<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use OsDownTime\Messaging\Events\AsyncPublishing\HashRange;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Position;

final readonly class LockedPointer implements Pointer
{
    public function __construct(
        private Position $position,
        private HashRange $range,
        private string $eventHandlerId,
        public int $version,
        public string $lockedBy,
        public \DateTimeImmutable $lockedAt,
    ) {
    }

    public static function from(string $rawPosition, int $minHash, int $maxHash, int $version, string $lockedBy, string $eventHandlerId, \DateTimeImmutable $lastLockedAt): self
    {
        return new self(Position::create($rawPosition), HashRange::create($minHash, $maxHash), $eventHandlerId, $version, $lockedBy, $lastLockedAt);
    }

    public function position(): Position
    {
        return $this->position;
    }

    public function range(): HashRange
    {
        return $this->range;
    }

    public function minHash(): int
    {
        return $this->range->minHash;
    }

    public function maxHash(): int
    {
        return $this->range->maxHash;
    }

    public function moveTo(string $newPosition): Pointer
    {
        return new self(
            Position::create($newPosition),
            $this->range,
            $this->eventHandlerId,
            $this->version,
            $this->lockedBy,
            $this->lockedAt,
        );
    }

    public function eventHandlerId(): string
    {
        return $this->eventHandlerId;
    }
}
