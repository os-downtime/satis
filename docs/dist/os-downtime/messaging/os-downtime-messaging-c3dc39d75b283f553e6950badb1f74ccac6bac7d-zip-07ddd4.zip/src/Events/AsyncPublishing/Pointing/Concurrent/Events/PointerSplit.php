<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class PointerSplit implements StoreEvent
{
    public function __construct(public int $splitPointerId, public array $newPointerIds)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::PointerSplit;
    }
}
