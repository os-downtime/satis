<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

interface RelayBatcher
{
    public function nextBatch(int $batchSize): BatchResult;
}
