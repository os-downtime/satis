<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Retrieving;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointer;
use OsDownTime\Messaging\Events\AsyncPublishing\Recording\StoreBasedEventRecorder;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\Envelope;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\PartitionedEventStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\Stamp;
use OsDownTime\Messaging\Events\SyncPublishing\EventDeliverer;
use Symfony\Component\Serializer\SerializerInterface;

final readonly class StoreBasedEventRetriever implements EventRetriever
{
    public function __construct(private EventDeliverer $eventDeliverer, private PartitionedEventStore $eventStore, private SerializerInterface $serializer)
    {
    }

    public function retrieveAndDeliver(Pointer $from, int $numberOfEventsToDeliver): RetrieveResult
    {
        $eventTypes = $this->eventDeliverer->eventTypesHandledBy($from->eventHandlerId());

        $envelopes = $this->eventStore->fetch($from->range(), $from->position(), $numberOfEventsToDeliver, $eventTypes);

        if (0 === count($envelopes)) {
            return RetrieveResult::nonRetrieved();
        }

        $events = array_map(
            fn (Envelope $envelope) => $this->serializer->deserialize(
                $envelope->serializedEvent,
                $envelope->stampValue(StoreBasedEventRecorder::EVENT_TYPE_STAMP_NAME),
                'json'
            ),
            $envelopes
        );

        $this->eventDeliverer->deliver($from->eventHandlerId(), ...$events);

        return new RetrieveResult(count($events), $envelopes[array_key_last($envelopes)]->stampValue(Stamp::UNIQUE_EVENT_ID));
    }
}
