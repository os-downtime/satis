<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use OsDownTime\ExtendedPhp\Serialization\ExternallySerializable;
use OsDownTime\ExtendedPhp\Versioning\Versioned;
use Symfony\Component\Serializer\Normalizer\PropertyNormalizer;
use Symfony\Component\Serializer\SerializerInterface;

final readonly class StoreForSerializableObjects extends BaseStore
{
    public function __construct(Connection $connection, string $serializableObjectType, private SerializerInterface $serializer)
    {
        parent::__construct($connection, $serializableObjectType);
    }

    private function serialize(ExternallySerializable $object): string
    {
        return $this->serializer->serialize(
            $object,
            'json',
            [
                PropertyNormalizer::NORMALIZE_VISIBILITY => PropertyNormalizer::NORMALIZE_PUBLIC |
                    PropertyNormalizer::NORMALIZE_PROTECTED |
                    PropertyNormalizer::NORMALIZE_PRIVATE,
            ]
        );
    }

    private function deserialize(string $serializedData, string $objectType): ExternallySerializable
    {
        return $this->serializer->deserialize(
            $serializedData,
            $objectType,
            'json',
            [
                PropertyNormalizer::NORMALIZE_VISIBILITY => PropertyNormalizer::NORMALIZE_PUBLIC |
                    PropertyNormalizer::NORMALIZE_PROTECTED |
                    PropertyNormalizer::NORMALIZE_PRIVATE,
            ]
        );
    }

    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void
    {
        if ($schema->hasTable($this->tableName)) {
            return;
        }

        if (!$isSameDatabase($this->connection->executeStatement(...))) {
            return;
        }

        $table = $schema->createTable($this->tableName);
        $table->addColumn('id', Types::STRING);
        $table->addColumn('version', Types::INTEGER, ['default' => 1]);
        $table->addColumn('object_type', Types::STRING);
        $table->addColumn('content', Types::JSON);
        $table->setPrimaryKey(['id']);
    }

    public function add(string $id, ExternallySerializable $object): void
    {
        $data = [
            'id' => $id,
            'object_type' => $object::class,
            'content' => $this->serialize($object),
        ];

        if ($object instanceof Versioned) {
            $data['version'] = $object->version();
        }

        $this->connection->insert(
            $this->tableName,
            $data
        );
    }

    public function get(string $id): ?ExternallySerializable
    {
        $retrieved = $this->connection->fetchAssociative(
            sprintf('SELECT * FROM %s WHERE id = :id', $this->tableName),
            ['id' => $id],
        );

        if (false === $retrieved) {
            return null;
        }

        return $this->restore($retrieved);
    }

    private function restore(array $row): ExternallySerializable
    {
        $result = $this->deserialize($row['content'], $row['object_type']);

        if ($result instanceof Versioned) {
            $result->withVersion($row['version']);
        }

        return $result;
    }

    public function update(string $id, ExternallySerializable $object): void
    {
        $qb = $this->connection->createQueryBuilder()
            ->update($this->tableName)
            ->set('content', ':sc')
            ->setParameter('sc', $this->serialize($object))
            ->set('version', 'version + 1')
            ->where('id = :id')
            ->setParameter('id', $id)
        ;

        if ($object instanceof Versioned) {
            $qb->andWhere('version = :vl')
                ->setParameter('vl', $object->version());
        }

        $numberOfUpdatedRows = $qb->executeStatement();

        if (0 === $numberOfUpdatedRows) {
            throw new VersionLockException();
        }
    }

    /**
     * @return ExternallySerializable[]
     */
    public function all(): array
    {
        $allRetrieved = $this->connection->fetchAllAssociative(sprintf('SELECT * FROM %s', $this->tableName));

        $result = [];

        foreach ($allRetrieved as $row) {
            $result[] = $this->restore($row);
        }

        return $result;
    }
}
