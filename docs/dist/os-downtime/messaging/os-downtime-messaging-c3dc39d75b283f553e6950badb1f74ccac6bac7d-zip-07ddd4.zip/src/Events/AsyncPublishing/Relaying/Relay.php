<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Relaying;

interface Relay
{
    public function batcherFor(string $workerId, string $eventHandlerId, \Closure $batcherHandler): void;
}
