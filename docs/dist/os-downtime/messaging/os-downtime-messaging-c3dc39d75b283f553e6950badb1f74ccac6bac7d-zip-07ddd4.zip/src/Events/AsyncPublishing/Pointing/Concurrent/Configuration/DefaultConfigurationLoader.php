<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration;

final readonly class DefaultConfigurationLoader implements ConfigurationLoader
{
    public function __construct(private ?StoreConfiguration $configurationOverride = null)
    {
    }

    public function load(): StoreConfiguration
    {
        if (null !== $this->configurationOverride) {
            return $this->configurationOverride;
        }

        return StoreConfiguration::default();
    }
}
