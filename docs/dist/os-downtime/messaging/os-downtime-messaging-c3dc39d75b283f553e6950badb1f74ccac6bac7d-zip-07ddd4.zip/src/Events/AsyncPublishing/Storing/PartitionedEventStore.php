<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Storing;

use OsDownTime\Messaging\Events\AsyncPublishing\HashRange;
use OsDownTime\Messaging\Events\AsyncPublishing\Position;

interface PartitionedEventStore
{
    /**
     * Enveloped events are appended into Partitions using the Envelope->streamName as partition key.
     * All appended envelopes get a global Position (across all Partitions).
     */
    public function append(Envelope ...$envelopes): void;

    /**
     * @return Envelope[]
     */
    public function fetch(HashRange $within, Position $startingAt, int $batchSize, ?array $typesOfEvents = null): array;
}
