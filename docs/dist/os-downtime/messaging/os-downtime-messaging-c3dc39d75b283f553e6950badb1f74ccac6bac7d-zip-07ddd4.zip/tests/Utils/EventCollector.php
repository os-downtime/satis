<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers\StoreEventHandler;

final class EventCollector implements StoreEventHandler
{
    public array $events = [];

    public function handle(StoreEvent $event): void
    {
        $this->events[] = $event;
    }
}
