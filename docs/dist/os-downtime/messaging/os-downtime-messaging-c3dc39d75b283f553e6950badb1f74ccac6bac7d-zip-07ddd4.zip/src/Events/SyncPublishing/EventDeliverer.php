<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\SyncPublishing;

use OsDownTime\Common\Domain\Event;

interface EventDeliverer
{
    public function eventTypesHandledBy(string $eventHandlerWithId): array;

    /**
     * @param string|null $onlyToEventHandlerWithId If null, deliver to all event handlers. If not null, deliver to the event handler with the given id.
     */
    public function deliver(?string $onlyToEventHandlerWithId, Event ...$events): void;
}
