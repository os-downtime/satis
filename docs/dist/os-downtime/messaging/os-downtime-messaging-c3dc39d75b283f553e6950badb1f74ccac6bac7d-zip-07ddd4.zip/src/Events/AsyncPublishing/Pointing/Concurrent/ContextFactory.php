<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use OsDownTime\ExtendedPhp\Time\Clock;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\ConfigurationLoader;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\StoreConfiguration;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\CollectingEventDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\DbalLockablePointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\DbalWorkerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerContext;

final readonly class ContextFactory
{
    private StoreConfiguration $configuration;

    public function __construct(
        private DbalLockablePointerStore $pointerStore,
        private DbalWorkerStore $workerStore,
        private Clock $clock,
        private CollectingEventDispatcher $dispatcher,
        ConfigurationLoader $configurationLoader,
    ) {
        $this->configuration = $configurationLoader->load();
    }

    public function contextFor(string $eventHandlerId, string $workerId): PointerContext
    {
        return new StopAwareContext(
            new HandlerWorkerContext(
                $this->pointerStore,
                $this->workerStore,
                $this->clock,
                $this->dispatcher,
                $this->configuration,
                $eventHandlerId,
                $workerId,
            ));
    }
}
