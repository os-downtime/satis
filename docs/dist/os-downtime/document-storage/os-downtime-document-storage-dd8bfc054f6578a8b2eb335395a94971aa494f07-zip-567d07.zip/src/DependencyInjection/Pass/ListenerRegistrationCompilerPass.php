<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\DependencyInjection\Pass;

use OsDownTime\DocumentStorage\DependencyInjection\Listener\SchemaConfigurationListener;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Definition;
use Symfony\Component\DependencyInjection\Reference;

final readonly class ListenerRegistrationCompilerPass implements CompilerPassInterface
{
    public const string ABLE_TO_CONFIGURE_SCHEMA_TAG = 'odt.document_storage.able_to_configure_schema';

    public function process(ContainerBuilder $container): void
    {
        if (!$container->hasDefinition('doctrine.dbal.connection.event_manager')) {
            return;
        }

        $eventManagerDefinition = $container->getDefinition('doctrine.dbal.connection.event_manager');

        $allAbleToConfigure = array_map(fn (string $serviceId) => new Reference($serviceId), array_keys($container->findTaggedServiceIds(self::ABLE_TO_CONFIGURE_SCHEMA_TAG)));

        $listenerDefinition = new Definition(SchemaConfigurationListener::class, [$allAbleToConfigure]);
        $listenerDefinition->addTag('doctrine.event_listener', ['event' => 'postGenerateSchema']);
        $listenerServiceId = 'odt.document_storage.schema_configuration_listener';
        $container->setDefinition($listenerServiceId, $listenerDefinition);

        $eventManagerDefinition->addMethodCall('addEventListener', [['postGenerateSchema'], new Reference($listenerServiceId)]);
    }
}
