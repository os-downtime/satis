<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Exceptions;

final class Method extends \RuntimeException
{
    public static function notImplemented(): self
    {
        $debug = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2)[1];

        return new self(sprintf('Method %s::%s not implemented yet.', $debug['class'], $debug['function']));
    }
}
