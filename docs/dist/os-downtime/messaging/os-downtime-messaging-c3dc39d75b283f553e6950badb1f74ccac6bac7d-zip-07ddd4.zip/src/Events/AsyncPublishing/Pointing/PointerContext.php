<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing;

interface PointerContext
{
    /**
     * @return bool true if is able to continue
     */
    public function usingPointerInContext(\Closure $pointerMover): bool;
}
