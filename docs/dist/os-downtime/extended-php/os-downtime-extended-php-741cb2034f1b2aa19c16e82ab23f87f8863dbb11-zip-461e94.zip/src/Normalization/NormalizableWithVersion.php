<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Normalization;

interface NormalizableWithVersion extends Normalizable
{
    public const string VERSION_KEY = '_version';

    /**
     * TODO: enforce array contains "_version" key     *.
     */
    public function normalize(): array;

    /**
     * TODO: enforce array contains "_version" key.
     */
    public static function denormalize(array $normalized): NormalizableWithVersion;
}
