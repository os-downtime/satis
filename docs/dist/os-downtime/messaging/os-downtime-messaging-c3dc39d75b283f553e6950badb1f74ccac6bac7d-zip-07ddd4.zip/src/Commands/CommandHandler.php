<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Commands;

use OsDownTime\Common\Application\CommandHandler as CommandCommandHandler;

interface CommandHandler extends CommandCommandHandler
{
    /**
     * @return string[]
     */
    public static function handledCommands(): array;
}
