<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class StoreInitializationFailed implements StoreEvent
{
    public function __construct(public string $eventHandlerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::StoreInitializationFailed;
    }
}
