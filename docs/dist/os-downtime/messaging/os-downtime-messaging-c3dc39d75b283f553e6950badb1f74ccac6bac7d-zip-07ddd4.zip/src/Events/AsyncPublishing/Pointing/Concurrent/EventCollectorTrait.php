<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent;

use Psr\EventDispatcher\EventDispatcherInterface;

trait EventCollectorTrait
{
    protected array $events = [];

    public function collectEvent(object $event): void
    {
        $this->events[] = $event;
    }

    public function dispatchCollectedEventsThrough(EventDispatcherInterface $dispatcher): void
    {
        $temp = $this->events;
        $this->events = [];
        foreach ($temp as $event) {
            $dispatcher->dispatch($event);
        }
    }
}
