<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

use Doctrine\DBAL\Schema\Schema;

interface SchemaConfigurator
{
    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void;
}
