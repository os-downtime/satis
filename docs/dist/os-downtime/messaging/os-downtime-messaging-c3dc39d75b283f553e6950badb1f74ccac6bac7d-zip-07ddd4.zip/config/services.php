<?php

declare(strict_types=1);

use OsDownTime\Common\Application\CommandBus;
use OsDownTime\Common\Domain\EventBus;
use OsDownTime\DocumentStorage\DependencyInjection\Pass\ListenerRegistrationCompilerPass;
use OsDownTime\ExtendedPhp\Time\Clock;
use OsDownTime\ExtendedPhp\Time\DefaultClock;
use OsDownTime\Messaging\Commands\ServiceLocatorCommandBus;
use OsDownTime\Messaging\Events\AsyncPublishing\AsyncEventBus;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\ConfigurationLoader;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Configuration\DefaultConfigurationLoader;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\ContextFactory;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\CooperatingWorkersStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\CollectingEventDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEventAwareDispatcher;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\LockablePointerStore\DbalLockablePointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers\EventLogger;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers\SubscriberToAllEvents;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\WorkerStore\DbalWorkerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\PointerStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Recording\EventRecorder;
use OsDownTime\Messaging\Events\AsyncPublishing\Recording\StoreBasedEventRecorder;
use OsDownTime\Messaging\Events\AsyncPublishing\Relaying\PointerBasedRelay;
use OsDownTime\Messaging\Events\AsyncPublishing\Relaying\Relay;
use OsDownTime\Messaging\Events\AsyncPublishing\Relaying\RelayCliCommand;
use OsDownTime\Messaging\Events\AsyncPublishing\Relaying\RelayWorker;
use OsDownTime\Messaging\Events\AsyncPublishing\Retrieving\EventRetriever;
use OsDownTime\Messaging\Events\AsyncPublishing\Retrieving\StoreBasedEventRetriever;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\DbalPartitionedEventStore;
use OsDownTime\Messaging\Events\AsyncPublishing\Storing\PartitionedEventStore;
use OsDownTime\Messaging\Events\SyncPublishing\EventDeliverer;
use OsDownTime\Messaging\Events\SyncPublishing\ServiceLocatorEventDeliverer;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;

use function Symfony\Component\DependencyInjection\Loader\Configurator\service;

return static function (ContainerConfigurator $container): void {
    $services = $container->services()
        ->defaults()
        ->autowire()
        ->autoconfigure()// TODO disable autowire and autoconfigure to follow Symfony's best practices for bundles
    ;

    $services->set(DbalPartitionedEventStore::class)->tag(ListenerRegistrationCompilerPass::ABLE_TO_CONFIGURE_SCHEMA_TAG);
    $services->alias(PartitionedEventStore::class, DbalPartitionedEventStore::class);

    $services->set(StoreBasedEventRetriever::class);
    $services->alias(EventRetriever::class, StoreBasedEventRetriever::class);

    $services->set(DefaultClock::class);
    $services->alias(Clock::class, DefaultClock::class);

    $services->set(DefaultConfigurationLoader::class);
    $services->alias(ConfigurationLoader::class, DefaultConfigurationLoader::class);

    $services->set(DbalLockablePointerStore::class)->tag(ListenerRegistrationCompilerPass::ABLE_TO_CONFIGURE_SCHEMA_TAG);

    $services->set(DbalWorkerStore::class)->tag(ListenerRegistrationCompilerPass::ABLE_TO_CONFIGURE_SCHEMA_TAG);

    $services->set(EventLogger::class);

    $services->set(SubscriberToAllEvents::class)->arg('$eventHandler', service(EventLogger::class));

    $services->set('odt.messaging.name_aware_event_dispatcher', StoreEventAwareDispatcher::class)->call('addSubscriber', [service(SubscriberToAllEvents::class)]);

    $services->set(CollectingEventDispatcher::class)->arg('$dispatcher', service('odt.messaging.name_aware_event_dispatcher'));

    $services->set(ContextFactory::class);

    $services->set(CooperatingWorkersStore::class);
    $services->alias(PointerStore::class, CooperatingWorkersStore::class);

    $services->set(PointerBasedRelay::class);
    $services->alias(Relay::class, PointerBasedRelay::class);

    $services->set(RelayWorker::class);

    $services->set(RelayCliCommand::class)->tag('console.command');

    $services->set(ServiceLocatorEventDeliverer::class);
    $services->alias(EventDeliverer::class, ServiceLocatorEventDeliverer::class);

    $services->set(StoreBasedEventRecorder::class);
    $services->alias(EventRecorder::class, StoreBasedEventRecorder::class);

    // Command bus
    $services->set(ServiceLocatorCommandBus::class);
    $services->alias(CommandBus::class, ServiceLocatorCommandBus::class);

    // Event bus
    $services->set(AsyncEventBus::class);
    //    $services->alias(EventBus::class, SyncEventBus::class);
    $services->alias(EventBus::class, AsyncEventBus::class);
};
