<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils\PartitionableCollection;

final class UniformHashing
{
    private array $alreadyAssigned;
    private array $hashes;
    private int $currentHash;

    public function __construct(int $minRange, int $maxRange, int $numberOfHashes)
    {
        $this->alreadyAssigned = [];
        $this->hashes = [];
        $this->currentHash = 0;

        $hashSize = intdiv($maxRange - $minRange, $numberOfHashes);

        for ($i = 1; $i < $numberOfHashes; ++$i) {
            $this->hashes[] = $i * $hashSize;
        }
    }

    public function hash(string $name): int
    {
        if (array_key_exists($name, $this->alreadyAssigned)) {
            return $this->alreadyAssigned[$name];
        }

        $index = $this->currentHash % count($this->hashes);
        $this->alreadyAssigned[$name] = $this->hashes[$index];
        ++$this->currentHash;

        return $this->alreadyAssigned[$name];
    }
}
