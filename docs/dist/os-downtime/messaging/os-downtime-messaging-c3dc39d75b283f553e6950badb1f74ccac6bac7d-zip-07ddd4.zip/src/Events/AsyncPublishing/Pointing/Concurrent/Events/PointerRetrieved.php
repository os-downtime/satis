<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class PointerRetrieved implements StoreEvent
{
    public function __construct(int $pointerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::PointerRetrieved;
    }
}
