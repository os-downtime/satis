# common
Common classes for domain oriented applications
