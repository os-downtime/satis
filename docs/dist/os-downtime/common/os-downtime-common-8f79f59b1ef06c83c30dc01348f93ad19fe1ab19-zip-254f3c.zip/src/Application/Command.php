<?php

declare(strict_types=1);

namespace OsDownTime\Common\Application;

interface Command
{
}
