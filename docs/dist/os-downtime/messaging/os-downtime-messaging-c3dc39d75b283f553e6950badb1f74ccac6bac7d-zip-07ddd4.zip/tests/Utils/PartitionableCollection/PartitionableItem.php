<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils\PartitionableCollection;

final class PartitionableItem implements \Stringable
{
    public function __construct(public readonly int $hash, public int $globalOrder, public readonly string $name, public array $handledAt = [])
    {
    }

    public function __toString(): string
    {
        return sprintf('%s-%s-%s-%s', $this->hash, $this->globalOrder, $this->name, implode(',', $this->handledAt));
    }

    public function toArray(): array
    {
        return [
            'hash' => $this->hash,
            'globalOrder' => $this->globalOrder,
            'name' => $this->name,
            'handledAt' => $this->handledAt,
        ];
    }

    public static function fromArray(array $data): self
    {
        return new self(
            $data['hash'],
            $data['globalOrder'],
            $data['name'],
            $data['handledAt']
        );
    }
}
