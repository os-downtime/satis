<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class WorkerFlaggedAsStale implements StoreEvent
{
    public function __construct(public string $staleWorkerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::StaleWorkerFlagged;
    }
}
