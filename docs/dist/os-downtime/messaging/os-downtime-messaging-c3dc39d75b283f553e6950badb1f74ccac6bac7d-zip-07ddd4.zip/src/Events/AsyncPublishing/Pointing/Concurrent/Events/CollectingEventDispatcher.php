<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

use Psr\EventDispatcher\EventDispatcherInterface;

final class CollectingEventDispatcher implements EventDispatcherInterface
{
    private array $events = [];

    public function __construct(private readonly EventDispatcherInterface $dispatcher)
    {
    }

    public function dispatch(object $event): void
    {
        $this->dispatcher->dispatch($event);
    }

    public function collectEvent(object $event): void
    {
        $this->events[] = $event;
    }

    public function dispatchCollectedEvents(): void
    {
        $temp = $this->events;
        $this->events = [];
        foreach ($temp as $event) {
            $this->dispatcher->dispatch($event);
        }
    }
}
