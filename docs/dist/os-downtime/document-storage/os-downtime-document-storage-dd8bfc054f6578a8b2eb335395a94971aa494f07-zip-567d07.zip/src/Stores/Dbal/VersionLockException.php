<?php

declare(strict_types=1);

namespace OsDownTime\DocumentStorage\Stores\Dbal;

final class VersionLockException extends \RuntimeException
{
    public static function for(string $normalizableObjectType): self
    {
        return new self(sprintf('"%s" was modified by someone else.', $normalizableObjectType));
    }
}
