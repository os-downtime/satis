<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;
use Doctrine\DBAL\Exception;

final readonly class DbalConnectionBuilder
{
    /**
     * @throws Exception
     */
    public static function build(string $dbParamsPrefix = 'db_'): Connection
    {
        return DriverManager::getConnection(ConnectionParams::load($dbParamsPrefix));
    }
}
