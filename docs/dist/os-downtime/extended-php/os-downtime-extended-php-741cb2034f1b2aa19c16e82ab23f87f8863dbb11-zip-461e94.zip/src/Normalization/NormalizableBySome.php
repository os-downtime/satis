<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Normalization;

interface NormalizableBySome extends Normalizable
{
    /**
     * @return string[]
     */
    public static function isNormalizableBy(): array;
}
