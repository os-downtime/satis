<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Normalization;

interface NormalizableWithVersionBySome extends NormalizableWithVersion
{
    /**
     * @return string[]
     */
    public static function isNormalizableBy(): array;
}
