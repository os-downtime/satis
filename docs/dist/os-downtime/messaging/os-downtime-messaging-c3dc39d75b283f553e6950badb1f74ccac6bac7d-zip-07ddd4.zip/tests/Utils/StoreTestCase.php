<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Tests\Utils;

use Doctrine\DBAL\Exception\TableNotFoundException;
use Doctrine\DBAL\Schema\Schema;
use PHPUnit\Framework\TestCase;

abstract class StoreTestCase extends TestCase
{
    protected function recreateSchema(Schema $toRecreate): void
    {
        $schemaManager = DbalConnectionBuilder::build()->createSchemaManager();

        try {
            $schemaManager->dropSchemaObjects($toRecreate);
        } catch (TableNotFoundException) {
        }

        $schemaManager->createSchemaObjects($toRecreate);
    }
}
