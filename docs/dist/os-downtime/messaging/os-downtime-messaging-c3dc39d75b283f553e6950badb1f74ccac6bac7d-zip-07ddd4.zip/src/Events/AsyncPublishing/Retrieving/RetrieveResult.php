<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Retrieving;

final readonly class RetrieveResult
{
    public function __construct(public int $totalDelivered, public ?string $lastUniqueEventIdDelivered)
    {
    }

    public static function nonRetrieved(): self
    {
        return new self(0, null);
    }
}
