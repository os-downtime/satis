<?php

declare(strict_types=1);

namespace OsDownTime\Common\Domain;

interface Event
{
    public function aggregateId(): string;

    public function aggregateVersion(): int;
}
