<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events;

final readonly class AlreadySignedOutWorkerStopped implements StoreEvent
{
    public function __construct(public string $workerId)
    {
    }

    public static function eventName(): EventName
    {
        return EventName::AlreadySignedOutWorkerStopped;
    }
}
