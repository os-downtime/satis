<?php

declare(strict_types=1);

namespace OsDownTime\ExtendedPhp\Time;

final class TimeTravelerClock implements Clock
{
    public function __construct(private int $secondsIntoTheFuture = 0)
    {
    }

    public function jumpAheadInSeconds(int $seconds): void
    {
        $this->secondsIntoTheFuture += $seconds;
    }

    public function now(): \DateTimeImmutable
    {
        if (0 === $this->secondsIntoTheFuture) {
            return new \DateTimeImmutable();
        }

        return (new \DateTimeImmutable())->modify("+ $this->secondsIntoTheFuture seconds");
    }
}
