<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Storing;

use Doctrine\DBAL\ArrayParameterType;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Types;
use OsDownTime\DocumentStorage\Stores\Dbal\AbleToConfigureSchema;
use OsDownTime\DocumentStorage\Stores\Dbal\SchemaConfigurator;
use OsDownTime\Messaging\Events\AsyncPublishing\HashRange;
use OsDownTime\Messaging\Events\AsyncPublishing\Position;
use Symfony\Component\Uid\Factory\UlidFactory;

final class DbalPartitionedEventStore implements PartitionedEventStore, SchemaConfigurator, AbleToConfigureSchema
{
    private const string TABLE_NAME = 'event_envelopes';

    public function __construct(private Connection $connection, private UlidFactory $ulidFactory)
    {
    }

    public function append(Envelope ...$envelopes): void
    {
        $params = $types = [];
        foreach ($envelopes as $envelope) {
            $params[] = $this->ulidFactory->create()->toRfc4122();
            $params[] = $envelope->streamName;
            $params[] = $envelope->streamVersion;
            $params[] = $envelope->serializedEvent;
            $params[] = $envelope->eventType;
            $params[] = json_encode(array_map(static fn (Stamp $stamp): array => ['name' => $stamp->name, 'value' => $stamp->value], iterator_to_array($envelope->stamps())));
            $params[] = self::hash($envelope->streamName);

            array_push($types, Types::STRING, Types::STRING, Types::BIGINT, Types::TEXT, Types::STRING, Types::TEXT, Types::BIGINT);
        }

        $affectedRows = $this->connection->executeStatement(
            sprintf(
                'INSERT INTO %s (id, stream_name, stream_version, payload, event_type, stamps, stream_hash) VALUES %s',
                self::TABLE_NAME,
                implode(', ', array_map(static fn (Envelope $envelope): string => '(?, ?, ?, ?, ?, ?, ?)', $envelopes)),
            ),
            $params,
            $types,
        );

        if ($affectedRows !== count($envelopes)) {
            throw new \RuntimeException('Not all envelops were appended');
        }
    }

    /**
     * @return Envelope[]
     */
    public function fetch(HashRange $within, Position $startingAt, int $batchSize, ?array $typesOfEvents = null): array
    {
        $qb = $this->connection->createQueryBuilder()
            ->select('e.*')
            ->from(self::TABLE_NAME, 'e')
            ->where('e.stream_hash >= :minH')
            ->andWhere('e.stream_hash < :maxH')
            ->andWhere('e.id > :lastId')
            ->setParameter('minH', $within->minHash)
            ->setParameter('maxH', $within->maxHash)
            ->setParameter('lastId', (string) $startingAt)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults($batchSize);

        if (null !== $typesOfEvents) {
            $qb->andWhere('e.event_type IN (:types)')
                ->setParameter('types', $typesOfEvents, ArrayParameterType::STRING);
        }

        $rows = $qb->executeQuery()
            ->fetchAllAssociative();

        $envelopes = [];

        foreach ($rows as $row) {
            $envelopes[] = new Envelope(
                $row['stream_name'],
                $row['stream_version'],
                $row['payload'],
                $row['event_type'],
                ...array_map(
                    static fn (array $stamp): Stamp => new Stamp($stamp['name'], $stamp['value']),
                    array_merge(json_decode($row['stamps'], true), [['name' => Stamp::UNIQUE_EVENT_ID, 'value' => $row['id']]]),
                ),
            );
        }

        return $envelopes;
    }

    public static function hash(string $input): int
    {
        return (int) hexdec(hash('murmur3a', $input));
    }

    public function configureSchema(Schema $schema, \Closure $isSameDatabase): void
    {
        if ($schema->hasTable(self::TABLE_NAME)) {
            return;
        }

        if (!$isSameDatabase($this->connection->executeStatement(...))) {
            return;
        }

        $table = $schema->createTable(self::TABLE_NAME);

        $table->addColumn('id', Types::STRING);
        $table->addColumn('stream_name', Types::STRING);
        $table->addColumn('stream_version', Types::BIGINT);
        $table->addColumn('payload', Types::TEXT);
        $table->addColumn('event_type', Types::STRING);
        $table->addColumn('stamps', Types::TEXT);
        $table->addColumn('recorded_at', Types::DATETIMETZ_IMMUTABLE, ['default' => 'now()']);
        $table->addColumn('stream_hash', Types::BIGINT);

        $table->setPrimaryKey(['id']);
        $table->addUniqueIndex(['stream_name', 'stream_version']);
    }

    public function configurator(): SchemaConfigurator
    {
        return $this;
    }
}
