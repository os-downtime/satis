<?php

declare(strict_types=1);

namespace OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Subscribers;

use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\EventName;
use OsDownTime\Messaging\Events\AsyncPublishing\Pointing\Concurrent\Events\StoreEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final readonly class SubscriberToAllEvents implements EventSubscriberInterface
{
    public function __construct(private StoreEventHandler $eventHandler)
    {
    }

    public static function getSubscribedEvents(): array
    {
        $result = [];

        foreach (EventName::cases() as $case) {
            $result[$case->value] = 'onEvent';
        }

        return $result;
    }

    public function onEvent(StoreEvent $event): void
    {
        $this->eventHandler->handle($event);
    }
}
